$(document).ready(function () {

    $('#pokemon').keypress(function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            var userInput = $(".form-control").val();
            var url = "https://pokeapi.co/api/v2/pokemon/" + userInput;
            $.ajax({
                type: "GET",
                url: url,
                dataType: "json",
    
                success: function (Pokedata) {//"success"--->cunado resulta exitoso
    
                    console.log(Pokedata);
    
                    var dataPoints = [];
    
                    tipoSecundario = '';
    
                    if (Pokedata.types.length === 1) {
                        tipoSecundario = '';
                    } else {
                        tipoSecundario = ' y ' + Pokedata.types[1].type.name;
                    }
                    
                    $('#pokeImage').attr("src",Pokedata.sprites.other.home.front_default);
                    $('#nombre').text("Nombre: " + Pokedata.species.name);
                    $('#peso').text("Peso: " + Pokedata.weight);
                    $('#altura').text("Altura: " + Pokedata.height);
                    $('#tipo').text("Tipo: " + Pokedata.types[0].type.name + tipoSecundario);
                    $('#numero').text("N° Pokedex: " + Pokedata.id);
                   
                    // aqui empieza el Grafico 
    
                    var options = {
                        title: {
                            text: "Estas son las Estadisticas"
                        },
                        subtitles: [{
                            text: "de mi pokemon"
                        }],
                        animationEnabled: true,
                        data: [{
                            type: "pie",
                            startAngle: 40,
                            toolTipContent: "<b>{label}</b>: {y}",// label nombre / y valor
                            showInLegend: "true",
                            legendText: "{label}",
                            indexLabelFontSize: 16,
                            indexLabel: "{label} - {y}",
                            dataPoints: dataPoints
                        }],
    
                    };
                    let datosApi = Pokedata.stats;
                    for (var i = 0; i < datosApi.length; i++) {
                        dataPoints.push({
                            y: datosApi[i].base_stat, label: datosApi[i].stat.name
                        })
                    }
                    $("#chartContainer").CanvasJSChart(options);
                },
    
                error: function () {
                    //console.log("hicimos la morición");
                    alert("hicimos la morición");
                }
    
            })
     
        }
      });



    $('#button2').on('click', function () {// con esto escuchamos el "button" hasta hacer click
        var userInput = $(".form-control").val();
        var url = "https://pokeapi.co/api/v2/pokemon/" + userInput;
        $.ajax({
            type: "GET",
            url: url,
            dataType: "json",

            success: function (Pokedata) {//"success"--->cunado resulta exitoso

                console.log(Pokedata);

                var dataPoints = [];

                tipoSecundario = '';

                if (Pokedata.types.length === 1) {
                    tipoSecundario = '';
                } else {
                    tipoSecundario = ' y ' + Pokedata.types[1].type.name;
                }
                
                $('#pokeImage').attr("src", Pokedata.sprites.other.home.front_default);
                $('#nombre').text("Nombre: " + Pokedata.species.name);
                $('#peso').text("Peso: " + Pokedata.weight);
                $('#altura').text("Altura: " + Pokedata.height);
                $('#tipo').text("Tipo: " + Pokedata.types[0].type.name + tipoSecundario);
                $('#numero').text("N° Pokedex: " + Pokedata.id);
               
                // aqui empieza el Grafico 

                var options = {
                    title: {
                        text: "Estas son las Estadisticas"
                    },
                    subtitles: [{
                        text: "de mi pokemon"
                    }],
                    animationEnabled: true,
                    data: [{
                        type: "pie",
                        startAngle: 40,
                        toolTipContent: "<b>{label}</b>: {y}",// label nombre / y valor
                        showInLegend: "true",
                        legendText: "{label}",
                        indexLabelFontSize: 16,
                        indexLabel: "{label} - {y}",
                        dataPoints: dataPoints
                    }],

                };
                let datosApi = Pokedata.stats;
                for (var i = 0; i < datosApi.length; i++) {
                    dataPoints.push({
                        y: datosApi[i].base_stat, label: datosApi[i].stat.name
                    })
                }
                $("#chartContainer").CanvasJSChart(options);
            },

            error: function () {
                //console.log("hicimos la morición");
                alert("Valor erroneo, ingrese un numero de 1 a 900");
            }

        })

    });
})