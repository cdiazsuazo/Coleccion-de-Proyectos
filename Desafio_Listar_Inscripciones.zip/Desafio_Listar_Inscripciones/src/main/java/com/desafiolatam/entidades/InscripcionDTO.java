package com.desafiolatam.entidades;

public class InscripcionDTO {
	
	private int idInsc;
	private String nombre;
	private String celular;
	private int idCurso;
	private int idFormaDePago;
	/**
	 * @return the idInsc
	 */
	public int getIdInsc() {
		return idInsc;
	}
	/**
	 * @param idInsc the idInsc to set
	 */
	public void setIdInsc(int idInsc) {
		this.idInsc = idInsc;
	}
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the celular
	 */
	public String getCelular() {
		return celular;
	}
	/**
	 * @param celular the celular to set
	 */
	public void setCelular(String celular) {
		this.celular = celular;
	}
	/**
	 * @return the idCurso
	 */
	public int getIdCurso() {
		return idCurso;
	}
	/**
	 * @param idCurso the idCurso to set
	 */
	public void setIdCurso(int idCurso) {
		this.idCurso = idCurso;
	}
	/**
	 * @return the idFormaDePago
	 */
	public int getIdFormaDePago() {
		return idFormaDePago;
	}
	/**
	 * @param idFormaDePago the idFormaDePago to set
	 */
	public void setIdFormaDePago(int idFormaDePago) {
		this.idFormaDePago = idFormaDePago;
	}
	@Override
	public String toString() {
		return "InscripcionDTO [idInsc=" + idInsc + ", nombre=" + nombre + ", celular=" + celular + ", idCurso="
				+ idCurso + ", idFormaDePago=" + idFormaDePago + "]";
	}
	
	
}