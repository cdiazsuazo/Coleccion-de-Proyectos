package com.desafiolatam.entidades;

public class FormaDePagoDTO {
	
	private int idFormaDePago;
	private String descripcion;
	private String recargo;
	/**
	 * @return the idFormaDePago
	 */
	public int getIdFormaDePago() {
		return idFormaDePago;
	}
	/**
	 * @param idFormaDePago the idFormaDePago to set
	 */
	public void setIdFormaDePago(int idFormaDePago) {
		this.idFormaDePago = idFormaDePago;
	}
	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}
	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	/**
	 * @return the recargo
	 */
	public String getRecargo() {
		return recargo;
	}
	/**
	 * @param recargo the recargo to set
	 */
	public void setRecargo(String recargo) {
		this.recargo = recargo;
	}
	
	

	
}