package com.desafiolatam.daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.desafiolatam.entidades.InscripcionDTO;

public class InscripcionDAO {
	public int insertarInscripcion(InscripcionDTO dto) throws SQLException, ClassNotFoundException {
		
		
		int max = 0;
		
		try {
			
		//Query para obtener una secuencia y asignar un id. La funcion MAX solo obtiene el valor de id_inscripcion
		//y le suma 1, con eso hacemos el incremento
		String consultaProximoId = " select max(codigo)+1 from inscripcion";
		//Query que insertara el valor
		String insertarInscripcion = "insert into inscripcion (nombre, telefono, id_curso, id_forma_pago) "
				+ "values (" + "'" + dto.getNombre() + "'" + " , "	+ dto.getCelular() + " , "	+ "'"
				+ dto.getIdCurso() + "'" + " , " + "'" + dto.getIdFormaDePago() + "'" + ")";
		
		
		//conexion a la base de datos y ejecucion de la sentencia
				Class.forName("org.postgresql.Driver");
				Connection conexion = null;
				
				conexion = DriverManager.getConnection("jdbc:postgresql://127.0.0.1:5432/Desafio_Listar_Inscripciones","postgres","admin");
		
				PreparedStatement stmt1 = conexion.prepareStatement(consultaProximoId);
				PreparedStatement stmt2 = conexion.prepareStatement(insertarInscripcion);
		  
	
			stmt1.executeQuery();// executeQuery ejecuta una condicionante, es como una consulta (executeQuery sirve para select, group by, y esas cosas)
			stmt2.executeUpdate();//executeUpdate es una accion que actualiza la base de datos (executeUpdate es exlucisvamente para update, delete, add)
			
			System.out.println("Registro Ingresado");
			
			/*ResultSet resultado = stmt1.executeQuery();
			if(resultado.next()) {
				max = resultado.getInt(1);
				stmt2.setInt(1, max);
				stmt2.setString(2, dto.getNombre());
				stmt2.setString(3, dto.getCelular());
				stmt2.setInt(4, dto.getIdCurso());
				stmt2.setInt(5, dto.getIdFormaDePago());
				
				if(stmt2.executeUpdate() != 1) {
					throw new RuntimeException("A ocurrido un error inesperado");
				}
			}*/
		}catch(Exception ex) {
			ex.printStackTrace();
			/*throw new RuntimeException("A ocurrido un error inesperado" + ex);*/
		}
		return max;
	}
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
public List<InscripcionDTO> obtieneInscripciones() throws SQLException, ClassNotFoundException {
		System.out.println("xXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
		//creamos la lista de objetos que devolveran los resultados
		List<InscripcionDTO> inscripciones = new ArrayList<InscripcionDTO>();
		
		//creamos la consulta a la base de datos
		
		
		try {
			
				
			String consultaSql = "select codigo, id_curso, nombre, telefono, id_forma_pago from inscripcion";
			
			//conexion a la base de datos y ejecucion de la sentencia
			Class.forName("org.postgresql.Driver");
			Connection conexion = null;
			String url = "jdbc:postgresql://127.0.0.1:5432/Desafio_Listar_Inscripciones";
			conexion = DriverManager.getConnection(url, "postgres", "admin");
			
			PreparedStatement stmt = conexion.prepareStatement(consultaSql);
			
			ResultSet resultado = stmt.executeQuery();
			while(resultado.next()) {
				System.out.println("xXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
				InscripcionDTO inscripcion = new InscripcionDTO();
				inscripcion.setIdInsc(resultado.getInt("codigo"));
				inscripcion.setIdCurso(resultado.getInt("id_curso"));
				inscripcion.setNombre(resultado.getString("nombre"));
				inscripcion.setCelular(resultado.getString("telefono"));
				inscripcion.setIdFormaDePago(resultado.getInt("id_forma_pago"));
				inscripciones.add(inscripcion);
			}	
			System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"+ inscripciones);
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return inscripciones;
	}
	
	
}