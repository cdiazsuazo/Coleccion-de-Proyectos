//---------------------------------EJERCICIO NUMERO 2------------------------------------//

var cuadradoSinVida = document.getElementById("caja");

function agregaVida (color){

    cuadradoSinVida.style.backgroundColor = color;

}

document.getElementById('btn-1').addEventListener('click', function(){

    var boton = document.getElementById('btn-1');//Obtenemos el objeto
    var color = boton.style.backgroundColor;//obtenemos el color
    agregaVida(color);//mandamos a reemplazar con el color obtenido
    //alert('Todo bien');//verificamos que pasamos por aca
});

document.getElementById('btn-2').addEventListener('click', function(){

    var boton = document.getElementById('btn-2');//Obtenemos el objeto
    var color = boton.style.backgroundColor;//obtenemos el color
    agregaVida(color);//mandamos a reemplazar con el color obtenido
    //alert('Todo bien');//verificamos que pasamos por aca
});

document.getElementById('btn-3').addEventListener('click', function(){

    var boton = document.getElementById('btn-3');//Obtenemos el objeto
    var color = boton.style.backgroundColor;//obtenemos el color
    agregaVida(color);//mandamos a reemplazar con el color obtenido
    //alert('Todo bien');//verificamos que pasamos por aca
});

document.getElementById('btn-4').addEventListener('click', function(){

    var boton = document.getElementById('btn-4');//Obtenemos el objeto
    var color = boton.style.backgroundColor;//obtenemos el color
    agregaVida(color);//mandamos a reemplazar con el color obtenido
    //alert('Todo bien');//verificamos que pasamos por aca
});

document.getElementById('btn-5').addEventListener('click', function(){

    var boton = document.getElementById('btn-5');//Obtenemos el objeto
    var color = boton.style.backgroundColor;//obtenemos el color
    agregaVida(color);//mandamos a reemplazar con el color obtenido
    //alert('Todo bien');//verificamos que pasamos por aca
});

document.getElementById('btn-6').addEventListener('click', function(){

    var boton = document.getElementById('btn-6');//Obtenemos el objeto
    var color = boton.style.backgroundColor;//obtenemos el color
    agregaVida(color);//mandamos a reemplazar con el color obtenido
    //alert('Todo bien');//verificamos que pasamos por aca
});




