 

//---------------------------------EJERCICIO NUMERO 1------------------------------------//

var miForm = document.getElementById("formulario"); // se captura en la variable miForm usando id "formulario"

miForm.addEventListener("submit", function (event) {// aqui escucho el evento a realizar con el mouse, en este caso el submit y ejecuto una funcion "MiSubmit"
    BorraMensajeErrores();// quita el mensaje de error al ingresar los valores corresctos
    event.preventDefault();//aqui la prevencion de evento del formulario evita que la pagina se recargue nuevamente
   

    var TextoNombre = document.getElementById('nombre').value;// capturamos los valores del campo nombre
    var TextoAsunto = document.getElementById('asunto').value;//capturamos los valores del campo asunto
    var TextoMensaje = document.getElementById('mensaje').value;//capturamos los valores del campo mensaje

   

    var resultado = validarDatos(TextoNombre,TextoAsunto,TextoMensaje);

    if( resultado == true) {// si el reultado de la funcion validarDatos que se paso a la variable resultado es true ejecutara la funcion ingresoCorrecto
        ingresoCorrecto();
    };
});

function BorraMensajeErrores(){// esta funcion  quita el mensaje de error al ingresar los valores correctos

    document.querySelector(".resultado").innerHTML = "";
    document.querySelector(".errorNombre").innerHTML = "";
    document.querySelector(".errorAsunto").innerHTML = "";
    document.querySelector(".errorMensaje").innerHTML = "";

};

function ingresoCorrecto(){//en esta funcion agregamos el mensaje de envio con exito a la clase resultado del HTML

    document.querySelector(".resultado").innerHTML = "Mensaje enviado con exito";
};

function validarDatos(TextoNombre, TextoAsunto, TextoMensaje) {//en esta funcion validamos que los datos ingresados son correctos con el formato solicitado con el metodo test() y en este caso solo se permiten letras y dejamos la variable pasamosLaValidacion en false para que no se ejecuta la funcion ingresoCorrecto

    var pasamosLaValidacion = true;
    var validacionNombre =  /[a-zA-Z]/gim;

    if (validacionNombre.test(TextoNombre) == false) {

        document.querySelector(".errorNombre").innerHTML = "El nombre es requerido";
        pasamosLaValidacion = false;
    };
    
    var validacionAsunto = /[a-zA-Z]/gim;

    if (validacionAsunto.test(TextoAsunto) == false) {

        document.querySelector(".errorAsunto").innerHTML = "El Asunto es requerido";
        pasamosLaValidacion = false;
    };

    var validacionMensaje = /[a-zA-Z]/gim;

    if (validacionMensaje.test(TextoMensaje) == false) {

        document.querySelector(".errorMensaje").innerHTML = "El Mensaje es requerido";
        pasamosLaValidacion = false;
    };

    

    return pasamosLaValidacion;//retornamos pasamosLaValidacion en este caso con false
 

};
 







