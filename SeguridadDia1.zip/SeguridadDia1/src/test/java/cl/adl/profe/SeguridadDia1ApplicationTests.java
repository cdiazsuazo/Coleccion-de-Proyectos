package cl.adl.profe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeguridadDia1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
