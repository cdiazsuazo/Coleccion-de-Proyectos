package EjercicioIndianaJeans;
/*
 * 
 * @author Cristian Diaz
 *
 */
import java.util.List;


public abstract class Exportador {

	public  void exportar (String nombreArchivo, String ruta, List<Producto> listaProductos) {
		
		
	}

}
