package EjercicioIndianaJeans;
/*
 * 
 * @author Cristian Diaz
 *
 */
 

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.List;

public class ExportadorTxt extends Exportador{
	
	public void exportar(String nombreArchivo, String ruta, List<Producto> listaProductos) {
		
		if(listaProductos.size()==0) {//confirma si la lista esta vacia
			System.out.println("La lista actualmente esta vacia, favor agregue productos a exportar");
			
		}else {
			String archivo = ruta+"/"+nombreArchivo + ".txt";
			
			File crearCarpeta = new File(ruta);
			File crearArchivo = new File(archivo);
			
			try {
				
				if(!crearCarpeta.exists()) {
					crearCarpeta.mkdir();
				}
				if(crearArchivo.exists()) {
					
					crearArchivo.delete();//Confirma si mi archivo ya existe , si ya existe , borra el archivo existente
					
				}
				FileWriter escritor = new FileWriter(crearArchivo);
				BufferedWriter escritorb = new BufferedWriter(escritor);
				
				for(Producto producto : listaProductos) {
					escritorb.write("Articulo:");
					escritorb.write(producto.getArticulo());
					escritorb.write("Codigo:");
					escritorb.write(producto.getCodigo());
					escritorb.write("Color:");
					escritorb.write(producto.getColor());
					escritorb.write("Descripcion:");
					escritorb.write(producto.getDescripcion());
					escritorb.write("Marca");
					escritorb.write(producto.getMarca());
					escritorb.write("Precio:");
					escritorb.write(producto.getPrecio());
					escritorb.write("Talla:");
					escritorb.write(producto.getTalla());
					escritorb.write("Articulo:");
					escritorb.newLine();
					
				}
				
				escritor.close();//cerrar el escritor si o si
				System.out.println("Datos correctamente exportados a txt");
						
			}catch(Exception Error) {
				
				System.out.println("Error, archivo no se puede crear, se encontro el siguiente problema" + Error.getMessage());
				
			}
			
		}
		
		Utilidad.EsperaYLimpieza();
	}

}
