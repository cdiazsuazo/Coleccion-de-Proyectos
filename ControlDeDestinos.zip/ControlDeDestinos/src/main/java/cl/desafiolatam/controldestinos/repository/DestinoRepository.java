package cl.desafiolatam.controldestinos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.desafiolatam.controldestinos.modelo.Destino;

public interface DestinoRepository extends JpaRepository<Destino, Integer> {

}
