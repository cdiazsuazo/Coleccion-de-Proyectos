package cl.desafiolatam.controldestinos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.desafiolatam.controldestinos.modelo.Pasajero;

public interface PasajeroRepository extends JpaRepository<Pasajero, Integer> {

}
