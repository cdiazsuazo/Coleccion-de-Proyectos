package cl.desafiolatam.controldestinos.modelo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name = "SQ_PASAJERO", initialValue = 1, allocationSize = 1)
public class Pasajero {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "")
	@Column(columnDefinition = "NUMERIC(19,0)")
	private Integer id;
	private String rut;
	private String nombre;
	private String apellido;
	@Column(columnDefinition = "NUMERIC(19,0)")
	private Integer edad;
	private String ciudad_natal;
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "pasajero")
	private List<Destino> destino;
	
	public Pasajero(Integer id, String rut, String nombre, String apellido, Integer edad, String ciudad_natal,
			List<Destino> destino) {
		super();
		this.id = id;
		this.rut = rut;
		this.nombre = nombre;
		this.apellido = apellido;
		this.edad = edad;
		this.ciudad_natal = ciudad_natal;
		this.destino = destino;
	}

	public Pasajero() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRut() {
		return rut;
	}

	public void setRut(String rut) {
		this.rut = rut;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public Integer getEdad() {
		return edad;
	}

	public void setEdad(Integer edad) {
		this.edad = edad;
	}

	public String getCiudad_natal() {
		return ciudad_natal;
	}

	public void setCiudad_natal(String ciudad_natal) {
		this.ciudad_natal = ciudad_natal;
	}

	public List<Destino> getDestino() {
		return destino;
	}

	public void setDestino(List<Destino> destino) {
		this.destino = destino;
	}

	@Override
	public String toString() {
		return rut + ", " + nombre + ", " + apellido + ", "
				+ edad + ", " + ciudad_natal;
	}

}
