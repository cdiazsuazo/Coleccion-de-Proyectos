package cl.desafiolatam.controldestinos.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import cl.desafiolatam.controldestinos.modelo.Destino;
import cl.desafiolatam.controldestinos.service.DestinoService;
import cl.desafiolatam.controldestinos.service.PasajeroService;
import cl.desafiolatam.controldestinos.vo.DestinoVO;

@Controller
public class DestinoController {
	
	@Autowired
	private DestinoService svc;
	
	@Autowired
	private PasajeroService svcPasajero;
	
	@GetMapping({ "/", "destinos" })
	public String listarDestinos(Model model, @RequestParam(defaultValue = "1") int p) {
		
		model.addAttribute("listaDestinos", svc.findAll());
		return "home";
	}
	
	@GetMapping("/agregardestino")
	public ModelAndView agregar(Model model) {
		
		model.addAttribute("listaPasajeros", svcPasajero.findAll());
		return new ModelAndView("agregardestino");
	}
	
	@PostMapping("/agregar")
	public ModelAndView agregarDestino(@ModelAttribute Destino destino) {
		
		DestinoVO respuestaServicio = svc.save(destino);
		
		if(respuestaServicio.getCodigo().equals("0")) {
			return new ModelAndView("redirect:/destinos");
		} else {
			return new ModelAndView("redirect:/error");
		}
	}

}
