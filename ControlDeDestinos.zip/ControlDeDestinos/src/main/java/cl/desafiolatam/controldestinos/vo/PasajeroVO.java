package cl.desafiolatam.controldestinos.vo;

import java.util.List;

import cl.desafiolatam.controldestinos.modelo.Pasajero;

public class PasajeroVO extends GenericVO {
	
	List<Pasajero> pasajeros;

	public PasajeroVO(String mensaje, String codigo, List<Pasajero> pasajeros) {
		super(mensaje, codigo);
		this.pasajeros = pasajeros;
	}

	public PasajeroVO() {
		super();
	}

	public List<Pasajero> getPasajeros() {
		return pasajeros;
	}

	public void setPasajeros(List<Pasajero> pasajeros) {
		this.pasajeros = pasajeros;
	}

	@Override
	public String toString() {
		return "PasajeroVO [pasajeros=" + pasajeros + "]";
	}

}
