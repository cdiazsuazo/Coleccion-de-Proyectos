package cl.desafiolatam.controldestinos.vo;

import java.util.List;

import cl.desafiolatam.controldestinos.modelo.Destino;

public class DestinoVO extends GenericVO {
	
	List<Destino> destinos;

	public DestinoVO(String mensaje, String codigo, List<Destino> destinos) {
		super(mensaje, codigo);
		this.destinos = destinos;
	}

	public DestinoVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public List<Destino> getDestinos() {
		return destinos;
	}

	public void setDestinos(List<Destino> destinos) {
		this.destinos = destinos;
	}

	@Override
	public String toString() {
		return "DestinoVO [getMensaje()=" + getMensaje() + ", getCodigo()=" + getCodigo() + ", toString()="
				+ super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}

}
