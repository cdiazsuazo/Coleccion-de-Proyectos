package cl.desafiolatam.controldestinos.service;

import cl.desafiolatam.controldestinos.modelo.Destino;
import cl.desafiolatam.controldestinos.vo.DestinoVO;

public interface DestinoService {
	
	public DestinoVO save(Destino destino);
	public DestinoVO findAll();

}
