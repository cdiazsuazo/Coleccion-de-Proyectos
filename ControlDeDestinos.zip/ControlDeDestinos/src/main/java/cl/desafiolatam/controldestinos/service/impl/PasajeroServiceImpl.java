package cl.desafiolatam.controldestinos.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.desafiolatam.controldestinos.modelo.Pasajero;
import cl.desafiolatam.controldestinos.repository.PasajeroRepository;
import cl.desafiolatam.controldestinos.service.PasajeroService;
import cl.desafiolatam.controldestinos.vo.PasajeroVO;

@Service
public class PasajeroServiceImpl implements PasajeroService {
	
	private final static Logger logger = LoggerFactory.getLogger(PasajeroServiceImpl.class);
	
	@Autowired
	PasajeroRepository dao;
	PasajeroVO respuesta;

	@Override
	@Transactional
	public PasajeroVO save(Pasajero pasajero) {

		respuesta = new PasajeroVO("Ha ocurrido un error!", "104", new ArrayList<Pasajero>());
		
		try {
			dao.save(pasajero);
			respuesta.setMensaje("Se ha añadido correctamente el pasajero");
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.error("Ha ocurrido un error al ingresar el pasajero", e);
		}
		
		return respuesta;
	}

	@Override
	@Transactional(readOnly = true)
	public PasajeroVO findAll() {

		respuesta = new PasajeroVO("Ha ocurrido un error!", "104", new ArrayList<Pasajero>());

		try {
			List<Pasajero> pasajeros = dao.findAll();
			if(pasajeros.size() > 0) {
				respuesta.setPasajeros(pasajeros);
				respuesta.setMensaje("Se han encontrado los pasajeros");
				respuesta.setCodigo("0");
			} else {
				respuesta.setMensaje("No se han encontrado los pasajeros");
				respuesta.setCodigo("104");
			}
		} catch (Exception e) {
			logger.error("Error al encontrar los registros", e);
		}
		
		return respuesta;
	}

}
