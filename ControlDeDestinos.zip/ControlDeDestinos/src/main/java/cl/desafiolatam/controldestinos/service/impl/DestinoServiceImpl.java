package cl.desafiolatam.controldestinos.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.desafiolatam.controldestinos.modelo.Destino;
import cl.desafiolatam.controldestinos.repository.DestinoRepository;
import cl.desafiolatam.controldestinos.service.DestinoService;
import cl.desafiolatam.controldestinos.vo.DestinoVO;

@Service
public class DestinoServiceImpl implements DestinoService {
	
	private final static Logger logger = LoggerFactory.getLogger(DestinoServiceImpl.class);
	
	@Autowired
	DestinoRepository dao;
	DestinoVO respuesta;

	@Override
	@Transactional
	public DestinoVO save(Destino destino) {
		
		respuesta = new DestinoVO("Ha ocurrido un error", "104", new ArrayList<Destino>());
		
		try {
			dao.save(destino);
			respuesta.setMensaje("Se ha añadido correctamente el destino");
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.error("Ha ocurrido un error al añadir el destino", e);
		}
		
		return respuesta;
	}

	@Override
	@Transactional(readOnly = true)
	public DestinoVO findAll() {
		
		respuesta = new DestinoVO("Ha ocurrido un error", "104", new ArrayList<Destino>());

		try {
			List<Destino> destinos = dao.findAll();
			if(destinos.size() > 0) {
				respuesta.setDestinos(destinos);
				respuesta.setMensaje("Se han encontrado los destinos");
				respuesta.setCodigo("0");
			} else {
				respuesta.setMensaje("No se han encontrado destinos");
				respuesta.setCodigo("104");
			}
		} catch (Exception e) {
			logger.error("Error al buscar los registros", e);
		}
		
		return respuesta;
	}

}
