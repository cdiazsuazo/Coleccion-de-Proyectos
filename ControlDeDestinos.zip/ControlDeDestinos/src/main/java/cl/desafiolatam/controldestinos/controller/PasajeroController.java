package cl.desafiolatam.controldestinos.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import cl.desafiolatam.controldestinos.modelo.Pasajero;
import cl.desafiolatam.controldestinos.service.DestinoService;
import cl.desafiolatam.controldestinos.service.PasajeroService;
import cl.desafiolatam.controldestinos.vo.PasajeroVO;

@Controller
public class PasajeroController {
	
	@Autowired
	private PasajeroService svc;
	
	@Autowired
	private DestinoService svcDestino;
	
	@GetMapping({ "/pasajeros" })
	public String listarPasajeros(Model model, @RequestParam(defaultValue = "1") int p) {
		
		model.addAttribute("listaPasajeros", svc.findAll());
		return "pasajeros";
	}
	
	@GetMapping("/agregarpasajero")
	public ModelAndView agregar(Model model) {
		
		model.addAttribute("listaDestinos", svcDestino.findAll());
		return new ModelAndView("agregarpasajero");
	}
	
	@PostMapping("/agregarpasajero2")
	public ModelAndView agregarPasajero(@ModelAttribute Pasajero pasajero) {
		
		PasajeroVO respuestaServicio = svc.save(pasajero);
		
		if(respuestaServicio.getCodigo().equals("0")) {
			return new ModelAndView("redirect:/pasajeros");
		} else {
			return new ModelAndView("redirect:/error");
		}
	}

}
