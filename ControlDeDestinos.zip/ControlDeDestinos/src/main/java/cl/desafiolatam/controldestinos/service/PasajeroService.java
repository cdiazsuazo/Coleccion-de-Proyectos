package cl.desafiolatam.controldestinos.service;

import cl.desafiolatam.controldestinos.modelo.Pasajero;
import cl.desafiolatam.controldestinos.vo.PasajeroVO;

public interface PasajeroService {
	
	public PasajeroVO save(Pasajero pasajero);
	public PasajeroVO findAll();

}
