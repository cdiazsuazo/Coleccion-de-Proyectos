package cl.adl.inyeccion;

public class ServicioEnvioPedido {
	
	public void enviarPedido() {
		System.out.println("Enviar pedido");
	}

}
