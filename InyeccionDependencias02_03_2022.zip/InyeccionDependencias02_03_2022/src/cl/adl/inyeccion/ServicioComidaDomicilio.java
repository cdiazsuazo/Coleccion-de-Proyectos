package cl.adl.inyeccion;

public class ServicioComidaDomicilio {
	
	ServicioRegistroPedido servicioRegistro;
	ServicioCobroPedido servicioCobro;
	ServicioEnvioPedido servicioEnvio;
	
	public ServicioComidaDomicilio(ServicioRegistroPedido servicioRegistro, ServicioCobroPedido servicioCobro, 
			ServicioEnvioPedido servicioEnvio) {
		
		this.servicioRegistro = servicioRegistro;
		this.servicioCobro = servicioCobro;
		this.servicioEnvio = servicioEnvio;
	}
	
	public void enviar() {
		servicioRegistro.registrarPedido();
		servicioCobro.cobrarPedido();
		servicioEnvio.enviarPedido();
	}
	
	

}


/*

public void enviar() {
System.out.println("Registrar pedido");
System.out.println("Cobrar el pedido");
System.out.println("Enviar el pedido");
}

*/