package cl.adl.inyeccion;

public class Principal {

	public static void main(String[] args) {
		
		ServicioComidaDomicilio servicio = new ServicioComidaDomicilio(new ServicioRegistroPedido(), 
				new ServicioCobroPedido(), new ServicioEnvioVerificacionPedido());
		servicio.enviar();

	}

}
