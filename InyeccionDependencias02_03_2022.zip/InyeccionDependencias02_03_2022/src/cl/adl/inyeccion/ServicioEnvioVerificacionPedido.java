package cl.adl.inyeccion;

public class ServicioEnvioVerificacionPedido extends ServicioEnvioPedido {
	
	public void enviarPedido() {
		System.out.println("Verifico Pedido");
		super.enviarPedido();
	}

}
