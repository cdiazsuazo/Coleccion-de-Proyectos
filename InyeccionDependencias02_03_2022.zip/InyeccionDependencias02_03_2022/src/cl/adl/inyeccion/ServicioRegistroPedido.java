package cl.adl.inyeccion;

public class ServicioRegistroPedido {
	
	public void registrarPedido() {
		System.out.println("Registrar pedido");
	}

}
