package cl.adl.inyeccion;

public class ServicioCobroPedido {
	
	public void cobrarPedido() {
		System.out.println("Cobrar pedido");
	}

}
