package cl.desafiolatam.controldealumnos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControlDeAlumnosApplicationTests {

	@Test
	void contextLoads() {
	}

}
