package cl.desafiolatam.controldealumnos.service;

import cl.desafiolatam.controldealumnos.modelo.Alumno;
import cl.desafiolatam.controldealumnos.vo.AlumnoVO;

public interface AlumnoService {
	
	public AlumnoVO save(Alumno alumno);
	public AlumnoVO findAll();

}
