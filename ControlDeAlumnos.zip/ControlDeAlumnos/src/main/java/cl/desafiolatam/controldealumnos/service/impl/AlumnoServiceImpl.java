package cl.desafiolatam.controldealumnos.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.desafiolatam.controldealumnos.modelo.Alumno;
import cl.desafiolatam.controldealumnos.repository.AlumnoRepository;
import cl.desafiolatam.controldealumnos.service.AlumnoService;
import cl.desafiolatam.controldealumnos.vo.AlumnoVO;

@Service
public class AlumnoServiceImpl implements AlumnoService {
	
	private final static Logger logger = LoggerFactory.getLogger(AlumnoServiceImpl.class);
	
	@Autowired
	AlumnoRepository dao;
	AlumnoVO respuesta;

	@Override
	@Transactional
	public AlumnoVO save(Alumno alumno) {
		
		respuesta = new AlumnoVO("Ha ocurrido un error!", "104", new ArrayList<Alumno>());
		
		try {
			dao.save(alumno);
			respuesta.setMensaje("Se ha añadido correctamente el alumno");
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.error("Error al añadir al alumno", e);
		}
		
		return respuesta;
	}

	@Override
	@Transactional(readOnly = true)
	public AlumnoVO findAll() {
		
		respuesta = new AlumnoVO("Ha ocurrido un error!", "104", new ArrayList<Alumno>());
		
		try {
			List<Alumno> alumnos = dao.findAll();
			if (alumnos.size() > 0) {
				respuesta.setAlumnos(alumnos);
				respuesta.setMensaje("Se han encontrado los alumnos");
				respuesta.setCodigo("0");
			} else {
				respuesta.setMensaje("No se han encontrado registros");
				respuesta.setCodigo("104");
			}
		} catch (Exception e) {
			logger.error("Error al buscar los registros", e);
		}
		return respuesta;
	}

}
