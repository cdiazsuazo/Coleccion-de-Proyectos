package cl.desafiolatam.controldealumnos.vo;

import java.util.List;

import cl.desafiolatam.controldealumnos.modelo.Direccion;

public class DireccionVO extends GenericVO {
	
	List<Direccion> direcciones;

	public DireccionVO(String mensaje, String codigo, List<Direccion> direcciones) {
		super(mensaje, codigo);
		this.direcciones = direcciones;
	}

	public DireccionVO() {
		super();
	}

	public List<Direccion> getDirecciones() {
		return direcciones;
	}

	public void setDirecciones(List<Direccion> direcciones) {
		this.direcciones = direcciones;
	}

	@Override
	public String toString() {
		return "DireccionVO [getMensaje()=" + getMensaje() + ", getCodigo()=" + getCodigo() + ", toString()="
				+ super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}

}
