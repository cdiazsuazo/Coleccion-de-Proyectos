package cl.desafiolatam.controldealumnos.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.desafiolatam.controldealumnos.modelo.Direccion;
import cl.desafiolatam.controldealumnos.repository.DireccionRepository;
import cl.desafiolatam.controldealumnos.service.DireccionService;
import cl.desafiolatam.controldealumnos.vo.DireccionVO;

@Service
public class DireccionServiceImpl implements DireccionService {

private final static Logger logger = LoggerFactory.getLogger(AlumnoServiceImpl.class);
	
	@Autowired
	DireccionRepository dao;
	DireccionVO respuesta;

	@Override
	@Transactional
	public DireccionVO save(Direccion direccion) {
		
		respuesta = new DireccionVO("Ha ocurrido un error!", "104", new ArrayList<Direccion>());
		
		try {
			dao.save(direccion);
			respuesta.setMensaje("Se ha añadido correctamente la direccion");
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.error("Error al añadir la direccion", e);
		}
		
		return respuesta;
	}

	@Override
	@Transactional(readOnly = true)
	public DireccionVO findAll() {
		
		respuesta = new DireccionVO("Ha ocurrido un error!", "104", new ArrayList<Direccion>());
		
		try {
			List<Direccion> direcciones = dao.findAll();
			if (direcciones.size() > 0) {
				respuesta.setDirecciones(direcciones);
				respuesta.setMensaje("Se han encontrado las direcciones");
				respuesta.setCodigo("0");
			} else {
				respuesta.setMensaje("No se han encontrado registros");
				respuesta.setCodigo("104");
			}
		} catch (Exception e) {
			logger.error("Error al buscar los registros", e);
		}
		return respuesta;
	}

}
