package cl.desafiolatam.controldealumnos.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import cl.desafiolatam.controldealumnos.modelo.Alumno;
import cl.desafiolatam.controldealumnos.service.AlumnoService;
import cl.desafiolatam.controldealumnos.service.DireccionService;
import cl.desafiolatam.controldealumnos.vo.AlumnoVO;

@Controller
public class AlumnoController {

	@Autowired
	private AlumnoService svc;
	
	@Autowired
	private DireccionService svcDireccion;

	@GetMapping({ "/", "/alumnos" })
	public String listarAlumnos(Model model, @RequestParam(defaultValue = "1") int p) {

		model.addAttribute("listaAlumnos", svc.findAll());
		return "home";
	}

	@GetMapping("/agregaralumno")
	public ModelAndView agregar(Model model) {
		
		model.addAttribute("listaDirecciones", svcDireccion.findAll());
		return new ModelAndView("agregaralumno");
	}

	@PostMapping("/agregar")
	public ModelAndView agregarAlumno(@ModelAttribute Alumno alumno) {

		AlumnoVO respuestaServicio = svc.save(alumno);

		if (respuestaServicio.getCodigo().equals("0")) {
			return new ModelAndView("redirect:/alumnos");
		} else {
			return new ModelAndView("redirect:/error");
		}

	}

}
