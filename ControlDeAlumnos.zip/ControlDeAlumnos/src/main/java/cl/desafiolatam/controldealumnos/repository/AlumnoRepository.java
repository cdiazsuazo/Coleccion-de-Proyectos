package cl.desafiolatam.controldealumnos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.desafiolatam.controldealumnos.modelo.Alumno;

public interface AlumnoRepository extends JpaRepository<Alumno, Integer> {

}
