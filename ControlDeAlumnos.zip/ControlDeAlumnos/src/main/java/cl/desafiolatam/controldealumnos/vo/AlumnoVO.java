package cl.desafiolatam.controldealumnos.vo;

import java.util.List;

import cl.desafiolatam.controldealumnos.modelo.Alumno;

public class AlumnoVO extends GenericVO {
	
	List<Alumno> alumnos;

	public AlumnoVO(String mensaje, String codigo, List<Alumno> alumnos) {
		super(mensaje, codigo);
		this.alumnos = alumnos;
	}

	public AlumnoVO() {
		super();
	}

	public List<Alumno> getAlumnos() {
		return alumnos;
	}

	public void setAlumnos(List<Alumno> alumnos) {
		this.alumnos = alumnos;
	}

	@Override
	public String toString() {
		return "AlumnoVO [getMensaje()=" + getMensaje() + ", getCodigo()=" + getCodigo() + ", toString()="
				+ super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}

}
