package cl.desafiolatam.controldealumnos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.desafiolatam.controldealumnos.modelo.Direccion;

public interface DireccionRepository extends JpaRepository<Direccion, Integer> {

}
