package cl.desafiolatam.controldealumnos.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name = "SQ_DIRECCION", initialValue = 1, allocationSize = 1)
public class Direccion {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "")
	private Integer id;
	private String calle;
	private String numero;
	private String ciudad;
	private String tipo;
	
	public Direccion(Integer id, String calle, String numero, String ciudad, String tipo) {
		super();
		this.id = id;
		this.calle = calle;
		this.numero = numero;
		this.ciudad = ciudad;
		this.tipo = tipo;
	}

	public Direccion() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCalle() {
		return calle;
	}

	public void setCalle(String calle) {
		this.calle = calle;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	@Override
	public String toString() {
		return calle + ", " + numero + ", " + ciudad + ", "
				+ tipo;
	}
	
}
