package cl.desafiolatam.controldealumnos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControlDeAlumnosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControlDeAlumnosApplication.class, args);
	}

}
