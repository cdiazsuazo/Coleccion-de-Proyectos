package cl.desafiolatam.controldealumnos.service;

import cl.desafiolatam.controldealumnos.modelo.Direccion;
import cl.desafiolatam.controldealumnos.vo.DireccionVO;

public interface DireccionService {
	
	public DireccionVO save(Direccion direccion);
	public DireccionVO findAll();

}
