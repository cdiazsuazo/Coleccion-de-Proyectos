package servicio;

/*
 * 
 * @author Cristian Diaz
 *
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import modelo.Cliente;

public class ArchivoServicio extends Exportador{

	Scanner ingreso = new Scanner(System.in);

	public List<Cliente>cargarDatos(String fileName) { // metodo Lista cargar datos con el parametro String fileName 

		List<Cliente> listaClientes = new ArrayList<Cliente>();

		String ruta = ingreso.nextLine();// lo ingresado por consola se asigna a ingreso

		String ubicacion = ruta + "/" + fileName;//a ubicacion le asignamos la ruta y el nombre del archivo a cargar

		File creararchivo = new File (ubicacion);// le asignamos a creararchivo la obtencion de ubicacion del archivo a cargar

		try {
			if (!creararchivo.isFile()) {//confirmo si la ruta indicada por el usuario es archivo o no, si no es ,mostrar mensaje
				System.out.println("El archivo que esta intentando abrir no existe o no esta creado");
			}
			else {
				FileReader lectorArchivo = new FileReader(creararchivo);// con filereader y bufferedreader leemos el texdo del archivo
				BufferedReader lectorbkn = new BufferedReader(lectorArchivo);

				String datosArchivo = lectorbkn.readLine();//lee la primera linea del CSV y lo asigna a datos Archivo

				while(datosArchivo!=null) {//revisamos que datos Archivo no este vacio
					Cliente cliente = new Cliente();//Creamos un nuevo cliente que sea reemplazado con cada cliente
					String[] datos = datosArchivo.split(",",4);//Crea un Array estatico de tipo String que separa cada dato cuando se topa con una coma,con un limite de 4

					cliente.setRunCliente(datos[0]);//Accedo a cada espacio del Array datos e ingreso los datos al CSV a mi nuevo cliente
					cliente.setNombreCliente(datos[1]);
					cliente.setApellidoCliente(datos[2]);
					cliente.setAniosCliente(datos[3]);

					listaClientes.add(cliente);//cliente una vez armado, es agregado a la lista
					datosArchivo = lectorbkn.readLine();//Comienzo a leer la siguiente linea y los datos son nuevamente inicializados al inicio de mi while

				}
				lectorbkn.close();//siempre se cierra el lector

				
				utilidades.Utilidad.EsperaYLimpieza();

							}
		}catch (Exception e) {
			System.out.println("Error: Se ha generado el siguiente error al intentar leer el archivo" + e.getMessage());
		}
		return listaClientes;
	}



	@Override
	public void exportar(String fileName, List<Cliente> listaClientes) {

		Exportador exportador = new ExportadorCsv();//Creamos un nuevo exportador que sea reemplazado con cada Exportador Csv
		Exportador exportador2 = new ExportadorTxt();
		exportador.exportar(fileName, listaClientes);
		exportador2.exportar(fileName, listaClientes);

	}
}



