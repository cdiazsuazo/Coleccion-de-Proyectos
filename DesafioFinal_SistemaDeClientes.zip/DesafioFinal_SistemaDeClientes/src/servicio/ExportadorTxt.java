package servicio;

/*
 * 
 * @author Cristian Diaz
 *
 */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.List;
import java.util.Scanner;

import modelo.Cliente;
import utilidades.Utilidad;

public class ExportadorTxt extends Exportador{
	
	Scanner scanner = new Scanner(System.in);
	
	public void exportar( String fileName, List<Cliente> listaClientes) {
		
		

		if(listaClientes.size()==0) {//confirma si la lista esta vacia
			
			System.out.println("La lista se encuentra vacia, favor ingresar un clientea la lista");
		}else  {
			String separa = ",";
			System.out.println("------------Exportador datos TXT------------");
			System.out.println("Ingresa la ruta donde se exportara el archivo .txt");
			String rutaArchivo = scanner.nextLine();
			String elArchivo = rutaArchivo + "/" + fileName;//asignamos a "elArchivo" la ruta donde exportaremos el archivo txt

			
			File crearArchivo = new File(elArchivo);

			try {
				
				if( crearArchivo.exists()) {
					crearArchivo.delete();//Confirma si mi archivo ya existe , si ya existe , borra el archivo existente
					System.out.println("El archivo se sobre escribio");
				}
				FileWriter writer = new FileWriter(crearArchivo);
				BufferedWriter BufferedW = new BufferedWriter(writer);


				for (Cliente cliente : listaClientes) {

					BufferedW.append(cliente.getRunCliente()).append(separa).append(cliente.getNombreCliente()).append(separa)
					.append(cliente.getApellidoCliente()).append(separa).append(cliente.getAniosCliente());

					BufferedW.newLine();

				}

				BufferedW.close();//cerrar el BufferedW si o si
				System.out.println("El archivo se exporto correctamente");


			}catch (Exception error) {
				
				System.out.println("Hay un error al tratar de crear el archivo" + error.getMessage());
			}
			
			Utilidad.EsperaYLimpieza();


		}



	}
		
	
	
}


