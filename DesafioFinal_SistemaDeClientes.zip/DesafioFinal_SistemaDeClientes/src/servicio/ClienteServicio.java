package servicio;
/*
 * 
 * @author Cristian Diaz
 *
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import modelo.Cliente;

public class ClienteServicio {
	
	List<Cliente>listaClientes; //atributo de nombre List<Cliente>listaCliente
	
	/**
	 * 
	 */
	
	
	
	public ClienteServicio() {//constructor para una nueva ArrayList
		
		listaClientes = new ArrayList<>();
		
	}
	
	
	public void listarClientes() {
		
		if (listaClientes.size()!=0) {//confirmo si la lista no esta vacia
			
			for (Cliente cliente : listaClientes) {
				//se listan los datos de cliente
				
				System.out.println("-------------Datos del Cliente-------------");
				System.out.println();
				System.out.println("RUN del Cliente: "+ cliente.getRunCliente());
				System.out.println("Nombre del Cliente: "+ cliente.getNombreCliente());
				System.out.println("Apellido del Cliente: "+ cliente.getApellidoCliente());
				System.out.println("A�os como Cliente: "+ cliente.getAniosCliente() + " A�os");
				System.out.println();
				System.out.println("-------------------------------------------");
				
			}
			
		}else {
			System.out.println("Su lista no puede inicializar, no existe Cliente");
		}
		
		
		utilidades.Utilidad.EsperaYLimpieza();

	}
	
	public void agregarCliente(String nombreCliente, String apellidoCliente, String runCliente, String aniosCliente) {
		
		Cliente cliente = new Cliente(runCliente, nombreCliente, apellidoCliente, aniosCliente);// instancia de cliente para guardar para guardar clientes
		
		if (listaClientes!=null) {//confirmamos que la lista cliente no este vacia
			listaClientes.add(cliente);//aca agregamos a la lista cliente a un cliente
			System.out.println("Cliente agregado correctamente\n");
			System.out.println("--------------------------------");
		}else {
			System.out.println("no se puede agregar elemento a la lista debido a que esta no existe");
			
		}
		
		utilidades.Utilidad.EsperaYLimpieza();
	}
	Scanner editar = new Scanner(System.in);
	
	public void editarCliente(String runCliente, String nombreCliente, String apellidoCliente, String aniosCliente, Cliente cliente) {
		
		
		
		boolean continuar = false;
		do {
		// aca listamos los datos como menu del cliente para seleccionar el dato a editar 
		System.out.println("-------------Datos del Cliente a editar-------------");
		System.out.println("1. El Run del Cliente es: "+ cliente.getRunCliente());
		System.out.println("2. El Nombre del Cliente es: "+ cliente.getNombreCliente());
		System.out.println("3. El Apellido del Cliente es: "+ cliente.getApellidoCliente());
		System.out.println("4. Los A�os como Cliente son: "+ cliente.getAniosCliente() + "  A�os");
		System.out.println("Si no quieres editar Pulse numero 5 para Salir");
		System.out.println();
		System.out.println("----------------------------------------------------");
		System.out.println(" Ingrese Opcion a editar de los datos del Cliente: ");
		
		
		String opcion = editar.nextLine();// asignamos a opcion lo que ingrese por scanner
		
		switch (opcion) {// switch case para menu de edicion de cliente
		
		case "1":
			System.out.println("------------------------------------");
			System.out.println("Ingrese nuevo Run de Cliente: ");
			cliente.setRunCliente(editar.nextLine());
			System.out.println("------------------------------------");
			System.out.println("Run de Cliente fue editado con exito");
			System.out.println("**************************************\n");
			break;
			
		case "2":
			System.out.println("------------------------------------");
			System.out.println("Ingrese nuevo Nombre del Cliente: ");
			cliente.setNombreCliente(editar.nextLine());
			System.out.println("------------------------------------");
			System.out.println("Nombre de Cliente fue editado con exito");
			System.out.println("**************************************\n");
			break;
			
		case "3":
			System.out.println("------------------------------------");
			System.out.println("Ingrese nuevo Apellido del Cliente: ");
			cliente.setApellidoCliente(editar.nextLine());
			System.out.println("------------------------------------");
			System.out.println("Apellido de Cliente fue editado con exito");
			System.out.println("**************************************\n");
			break;
			
		case "4":
			System.out.println("------------------------------------");
			System.out.println("Ingrese nuevo A�o como Cliente: ");
			cliente.setAniosCliente(editar.nextLine());
			System.out.println("------------------------------------");
			System.out.println("A�os como Cliente fue editado con exito");
			System.out.println("**************************************\n");
			break;
		case "5":
			System.out.println("------------------------------------");
			System.out.println("Saliendo de editar Cliente");
			System.out.println("------------------------------------");
			continuar = true;
			break;
		default:
			System.out.println("Opcion erronea");
			System.out.println("**************************************\n");
			break;
			
		}
		}while (!continuar);
		
		
	}


	/**
	 * @return the listaClientes
	 */
	public List<Cliente> getListaClientes() {
		return listaClientes;
	}


	/**
	 * @param listaClientes the listaClientes to set
	 */
	public void setListaClientes(List<Cliente> listaClientes) {
		this.listaClientes = listaClientes;
	}
	
	

}
