package vista;

/*
 * 
 * @author Cristian Diaz
 *
 */

import java.util.List;
import java.util.Scanner;

import modelo.Cliente;
import servicio.ArchivoServicio;
import servicio.ClienteServicio;
import servicio.ExportadorCsv;
import servicio.ExportadorTxt;
import utilidades.Utilidad;

public class Menu {




	//**********************Instancias de Metodos*************************//
	ClienteServicio clienteServicio = new ClienteServicio();//Instancia de ClienteServicio
	ArchivoServicio archivoservicio = new ArchivoServicio();//Instancia de ArchivoServicio
	ExportadorCsv exportarCsv = new ExportadorCsv();// instancia de ExportadorCsv
	ExportadorTxt exportadorTxt = new ExportadorTxt();// instancia de ExportadorTxt

	//**********************Para Exportar el Archivo*************************//
	String fileName = "Clientes";// para exportar archivo
	String fileName1 = "DBClientes.csv"; // para importar archivo

	//**********************Recibe valores desde Teclado*************************//
	Scanner ingreso = new Scanner(System.in);// instancia de Scanner para recibir valores desde teclado

	//**********************Metodo Iniciar Menu*************************//
	public void iniciarMenu() {

		//**********************Se define boolean "continuar" como false*************************//
		boolean continuar = false;

		//**********************Navegacion por el menu*************************//
		do {
			System.out.println("-------------Menu del Sistema Cliente-------------");
			System.out.println("1. Listar Clientes");
			System.out.println("2. Agregar Cliente");
			System.out.println("3. Editar Cliente");
			System.out.println("4. Cargar Datos");
			System.out.println("5. Exportar Datos");
			System.out.println("6. Salir");
			System.out.println("--------------------------------------------------");
			System.out.println("Ingrese numero para elegir la opcion: ");

			String respuesta = ingreso.nextLine();

			switch(respuesta) {// con cada opcion ingresada llamamos al metodo especifico de esa opcion segun ,menu

			case "1":
				listarCliente();
				break;

			case "2":
				agregarCliente();
				break;

			case "3":
				editarCliente();
				break;

			case "4":
				importarDatos();
				break;

			case "5":
				exportarDatos();
				break;

			case "6":
				terminarPrograma();

			default:
				System.out.println("Opcion no Valida");

			}

		} while (!continuar);

	}

	private void listarCliente() {//metodo que  muestra lista de clientes agregados o importados

		clienteServicio.listarClientes();

	}

	private void agregarCliente() {// metodo para el ingreso de datos y llena un objeto de tipo Cliente
		
		
		System.out.println("--------Crear Archivo--------\n");
		System.out.println("Igrese Run del Cliente: ");
		String run = ingreso.nextLine();

		System.out.println("Igrese Nombre del Cliente: ");
		String nombre = ingreso.nextLine();

		System.out.println("Igrese Apellido del Cliente: ");
		String apellido = ingreso.nextLine();

		System.out.println("Igrese A�os como Cliente: ");
		String anios = ingreso.nextLine();

		clienteServicio.agregarCliente(nombre, apellido, run, anios);

	}

	private void editarCliente() {// metodo permite la edicion de algun cliente

		List<Cliente> listaCliente = clienteServicio.getListaClientes();

		System.out.println("Ingrese Run del Cliente a Editar: ");
		String editrun = ingreso.nextLine();
		int confirmar = 0;

		if(listaCliente.size()==0) {
			System.out.println("La lista se encuentra actualmente vacia, favor agregue clientes a la lista");
		}else {
			for (Cliente cliente : listaCliente) {
				if (cliente.getRunCliente().equals(editrun)) {
					String run = cliente.getRunCliente();
					String nombre = cliente.getNombreCliente();
					String apellido = cliente.getApellidoCliente();
					String anios = cliente.getAniosCliente();
					clienteServicio.editarCliente(run, nombre, apellido, anios, cliente);
					confirmar ++;

				}
			}if (confirmar == 0 ) {
				System.out.println("No se encontro el rut del cliente");
			}
		}

	}

	private void importarDatos() {// metodo para la carga de datos desde el archivo externo "DBClientes.csv" al ingresar su ruta
		
		System.out.println("-------------------Carga de datos Externos-------------------\n");
		
		System.out.println("Ingrese la ruta en donde se encuentra su archivo DBClientes.csv a importar");
		
		
		
		List<Cliente> listaClientes = clienteServicio.getListaClientes();
		List<Cliente> listaImportar = archivoservicio.cargarDatos(fileName1);
		
		if(listaImportar.size()!=0) {
			
			listaClientes.addAll(listaImportar);
			
			
			
			System.out.println("Los datos han sido agregados a la lista correctamente");
		}
		
		Utilidad.EsperaYLimpieza();
	}

	private void exportarDatos() { //metodo para exportar clientes en formato "txt" o "csv"
		
	System.out.println("--------Exportar Datos--------------");
	System.out.println("Seleccione el formato a Exportar");
	System.out.println("1. exportar CSV");
	System.out.println("2. exportar TXT");
	System.out.println("------------------------------------");
	System.out.println("Seleccione opcion a exportar");
	
	List<Cliente> listaClientes = clienteServicio.getListaClientes();
	String opcion = ingreso.nextLine();
	
	switch (opcion) {
	
	case "1":
		exportarCsv.exportar(fileName + ".csv", listaClientes);
		break;
		
	case "2":
		exportadorTxt.exportar(fileName + ".txt", listaClientes);
		break;
		
	default:
		System.out.println("Opcion incorrecta, vuelve a ingresar su opcion"); 	
	}

	}

	private void terminarPrograma() { //metodo para finalizar la ejecucion del sistema
		
		System.out.println("--------------------------");
		System.out.println("Ud eligio: Salir\n");
		
		Utilidad.EsperaYLimpieza();
		
		System.out.println("Abandonando el Menu.....");
		
		Utilidad.EsperaYLimpieza();
		
		System.out.println("Acaba de salir del sistema, hasta pronto");
		System.out.println("");
		
		Utilidad.EsperaYLimpieza();
		
		System.exit(0);

	}


}


