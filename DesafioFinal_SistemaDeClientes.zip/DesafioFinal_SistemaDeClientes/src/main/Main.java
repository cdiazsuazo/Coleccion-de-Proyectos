package main;

/*
 * 
 * @author Cristian Diaz
 * 
 */


import vista.Menu;

/*
 * 
 * @author Cristian Diaz
 * 
 *
 */

public class Main {

	public static void main(String[] args) {
		
		//instanciando metodo Menu
		
		Menu menu = new Menu();
		
		//ocupando mi metodo Menu
		menu.iniciarMenu();
		

	}

}
