package cl.desafiolatam.contactmanager.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import cl.desafiolatam.contactmanager.ProyectoContactManagerApplication;
import cl.desafiolatam.contactmanager.dao.ContactoRepository;
import cl.desafiolatam.contactmanager.modelo.Contacto;
import cl.desafiolatam.contactmanager.service.ContactoService;
import cl.desafiolatam.contactmanager.vo.ContactoVO;

@Service
public class ContactoServiceImpl implements ContactoService {
	
	private static final Logger logger = LoggerFactory.getLogger(ProyectoContactManagerApplication.class);
	
	@Autowired
	ContactoRepository dao;
	
	ContactoVO respuesta;
	
	@Override
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRES_NEW, rollbackFor = {Throwable.class})
	public ContactoVO add(Contacto contacto) {
		
		respuesta = new ContactoVO(new ArrayList<Contacto>(), "Ha ocurrido un error!", "104");
		
		try {
			dao.save(contacto);
			respuesta.setMensaje(String.format("Se ha guardado correctamente el usuario %s", contacto.getNombre()));
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.trace("Contacto service: Error al guardar el usuario", e);
		}
		
		return respuesta;
	}

	@Override
	@Transactional
	public ContactoVO delete(Contacto contacto) {

		respuesta = new ContactoVO(new ArrayList<Contacto>(), "Ha ocurrido un error!", "104");
		
		try {
			dao.delete(contacto);
			respuesta.setMensaje("Se ha eliminado con exito el contacto");
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.trace("Contacto service: error al eliminar el contacto", e);
		}

		return respuesta;
	}

	@Override
	@Transactional
	public ContactoVO update(Contacto contacto) {
		
		respuesta = new ContactoVO(new ArrayList<Contacto>(), "Ha ocurrido un error!", "104");
		
		try {
			dao.save(contacto);
			respuesta.setMensaje(String.format("Se ha actualizado con exito el contacto", contacto.getNombre()));
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.trace("Contacto service: error al actualizar el contacto");
		}
		
		return respuesta;
	}

	@Override
	@Transactional(readOnly = true)
	public ContactoVO findById(int id) {
		
		respuesta = new ContactoVO(new ArrayList<Contacto>(), "Ha ocurrido un error!", "104");
		
		try {
			Contacto contacto = dao.findById(id).get();
			respuesta.getContactos().add(contacto);
			respuesta.setMensaje("Se ha encontrado el contacto");
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.trace("Contacto service: error al buscar el contacto", e);
		}
		
		return respuesta;
	}

	@Override
	@Transactional(readOnly = true)
	public ContactoVO getAllContactos() {
		
		respuesta = new ContactoVO(new ArrayList<Contacto>(), "Ha ocurrido un error!", "104");
		
		try {
			List<Contacto> contactos = (List<Contacto>) dao.findAll();
			respuesta.setContactos(contactos);
			respuesta.setMensaje("Se han encontrado los contactos");
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.trace("Contacto service: error al encontrar los contactos");
		}
		
		return respuesta;
	}

	
}
