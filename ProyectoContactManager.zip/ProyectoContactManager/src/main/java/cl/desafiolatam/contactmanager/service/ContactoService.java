package cl.desafiolatam.contactmanager.service;

import cl.desafiolatam.contactmanager.modelo.Contacto;
import cl.desafiolatam.contactmanager.vo.ContactoVO;

public interface ContactoService {
	
	public ContactoVO add(Contacto contacto);
	public ContactoVO delete(Contacto contacto);
	public ContactoVO update(Contacto contacto);
	public ContactoVO findById(int id);
	public ContactoVO getAllContactos();
	
}
