package cl.desafiolatam.contactmanager.controlador;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import cl.desafiolatam.contactmanager.modelo.Contacto;
import cl.desafiolatam.contactmanager.service.ContactoService;
import cl.desafiolatam.contactmanager.vo.ContactoVO;

@Controller
public class ContactoController {
	
	private final static Logger logger = LoggerFactory.getLogger(ContactoController.class);
	
	@Autowired
	private ContactoService svc;
	
	@GetMapping({ "/contactManager" })
	public String home(Model model, @RequestParam(defaultValue="1") int p) {
		
		model.addAttribute("listaContactos", svc.getAllContactos());
		return "home";
	}
	
	@PostMapping("/agregar")
	public ModelAndView agregarContacto(@ModelAttribute Contacto contacto) {
		
		ContactoVO respuestaServicio = svc.add(contacto);
		
		if (respuestaServicio.getCodigo().equals("0")) {
			return new ModelAndView("redirect:/contactManager");
		} else {
			return new ModelAndView("redirect:/error");
		}
		
	}
	
	@GetMapping("/eliminar")
	public ModelAndView eliminarUsuario(Model model, @RequestParam String idContacto, RedirectAttributes ra) {
		
		ContactoVO respuestaServicio = new ContactoVO();
		respuestaServicio.setMensaje("No fue posible eliminar el contacto");
		
		try {
			Contacto contactoEliminar = new Contacto();
			contactoEliminar.setId_contacto(Integer.parseInt(idContacto));
			respuestaServicio = svc.delete(contactoEliminar);
			return new ModelAndView("redirect:/contactManager");
		} catch (Exception e) {
			logger.error("Error en el UsuarioController: Eliminar");
			e.printStackTrace();
		}
		
		respuestaServicio = svc.getAllContactos();
		ra.addAttribute("listaContactos", respuestaServicio);
		
		return new ModelAndView("redirect:/contactManager");
	}
	
	@GetMapping("/editarForm")
	public ModelAndView editarForm(Model model, @RequestParam String idContacto) {
		
		ContactoVO respuestaServicio = new ContactoVO();
		respuestaServicio.setMensaje("No se puede acceder a la pagina de editar");
		
		try {
			Integer id = Integer.parseInt(idContacto);
			respuestaServicio = svc.findById(id);
			model.addAttribute("listaContactos", respuestaServicio.getContactos().get(0));
			return new ModelAndView("editar");
		} catch (Exception e) {
			logger.error("Error al traer al traer el contacto");
			e.printStackTrace();
		}
		
		respuestaServicio = svc.getAllContactos();
		return new ModelAndView("redirect:/contactManager");
	}
	
	@PostMapping("/editar")
	public ModelAndView editar(@ModelAttribute Contacto contacto) {
		
		ContactoVO respuestaServicio = svc.update(contacto);
		
		if (respuestaServicio.getCodigo().equals("0")) {
			return new ModelAndView("redirect:/contactManager");
		} else {
			return new ModelAndView("redirect:/error");
		}
		
	}

	
}
