package cl.desafiolatam.contactmanager.dao;

import org.springframework.data.repository.CrudRepository;

import cl.desafiolatam.contactmanager.modelo.Contacto;

public interface ContactoRepository extends CrudRepository<Contacto, Integer> {

}
