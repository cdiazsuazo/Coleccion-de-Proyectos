package cl.desafiolatam.contactmanager.vo;

import java.util.List;

import cl.desafiolatam.contactmanager.modelo.Contacto;

public class ContactoVO extends GenericVisualObject {
	
	List<Contacto> contactos;
	
	public ContactoVO(List<Contacto> contactos, String mensaje, String codigo) {
		super(mensaje, codigo);
		this.contactos = contactos;
	}
	
	public ContactoVO() {
		
	}

	public List<Contacto> getContactos() {
		return contactos;
	}

	public void setContactos(List<Contacto> contactos) {
		this.contactos = contactos;
	}

	@Override
	public String toString() {
		return "ContactoVO [contactos=" + contactos + "]";
	}

}
