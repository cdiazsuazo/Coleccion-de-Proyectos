package cl.desafiolatam.contactmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoContactManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoContactManagerApplication.class, args);
	}

}
