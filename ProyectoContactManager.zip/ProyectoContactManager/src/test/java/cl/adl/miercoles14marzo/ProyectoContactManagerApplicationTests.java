package cl.adl.miercoles14marzo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoContactManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
