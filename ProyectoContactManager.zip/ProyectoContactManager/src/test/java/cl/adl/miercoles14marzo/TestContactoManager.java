package cl.adl.miercoles14marzo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

import cl.desafiolatam.contactmanager.ProyectoContactManagerApplication;
import cl.desafiolatam.contactmanager.dao.ContactoRepository;

@SpringBootTest
@ContextConfiguration(classes = ProyectoContactManagerApplication.class)
class TestContactoManager {
	
	@Autowired
	private ContactoRepository contactoRepository;

	@Test
	public void testGetAllContactos() {
		
		assertNotNull(contactoRepository.findAll());
		
	}
	
	@Test
	public void testFindById() {
		
		assertNotNull(contactoRepository.findById(6));
		
	}

}
