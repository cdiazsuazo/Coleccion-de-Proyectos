package cl.desafiolatam.bibliotecabooklet.vo;

import java.util.List;

import cl.desafiolatam.bibliotecabooklet.modelo.Libro;

public class LibroVO extends GenericVisualObject {
	
	List<Libro> libros;

	public LibroVO(String mensaje, String codigo, List<Libro> libros) {
		super(mensaje, codigo);
		this.libros = libros;
	}
	
	public LibroVO() {
		
	}

	public List<Libro> getLibros() {
		return libros;
	}

	public void setLibros(List<Libro> libros) {
		this.libros = libros;
	}

	@Override
	public String toString() {
		return "LibroVO [libros=" + libros + "]";
	}
	
}
