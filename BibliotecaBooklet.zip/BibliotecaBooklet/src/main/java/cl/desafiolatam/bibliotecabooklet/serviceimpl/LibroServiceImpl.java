package cl.desafiolatam.bibliotecabooklet.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.desafiolatam.bibliotecabooklet.dao.LibroMapper;
import cl.desafiolatam.bibliotecabooklet.dao.LibroRepository;
import cl.desafiolatam.bibliotecabooklet.modelo.Libro;
import cl.desafiolatam.bibliotecabooklet.service.LibroService;
import cl.desafiolatam.bibliotecabooklet.vo.LibroVO;

@Service
public class LibroServiceImpl implements LibroService {

	private static final Logger logger = LoggerFactory.getLogger(LibroServiceImpl.class);

	@Autowired
	LibroRepository dao;
	LibroVO respuesta;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	@Transactional
	public LibroVO add(Libro libro) {

		respuesta = new LibroVO("Ha ocurrido un error!", "104", new ArrayList<Libro>());

		try {
			dao.save(libro);
			respuesta.setMensaje(String.format("Se ha guardado correctamente el libro %s", libro.getTitulo()));
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.error("Ha ocurrido un error al añadir el libro!", e);
		}

		return respuesta;
	}

	@Override
	@Transactional
	public LibroVO delete(Libro libro) {

		respuesta = new LibroVO("Ha ocurrido un error!", "104", new ArrayList<Libro>());

		try {
			dao.delete(libro);
			respuesta.setMensaje(String.format("Se ha eliminado correctamente el libro %s", libro.getTitulo()));
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.error("Ha ocurrido un error al eliminar el libro!", e);
		}

		return respuesta;

	}

	@Override
	@Transactional
	public LibroVO update(Libro libro) {

		respuesta = new LibroVO("Ha ocurrido un error!", "104", new ArrayList<Libro>());

		try {
			dao.save(libro);
			respuesta.setMensaje(String.format("Se ha guardado correctamente el libro %s", libro.getTitulo()));
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.error("Ha ocurrido un error al añadir el libro!", e);
		}

		return respuesta;

	}

	@Override
	@Transactional(readOnly = true)
	public LibroVO findById(int id) {

		respuesta = new LibroVO("Ha ocurrido un error!", "104", new ArrayList<Libro>());

		try {
			Libro libro = dao.findById(id).get();
			respuesta.getLibros().add(libro);
			respuesta.setMensaje("Se ha encontrado el registro");
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.error("Error al encontrar el registro", e);
		}

		return respuesta;
	}

	@Override
	@Transactional(readOnly = true)
	public List<Libro> getAllLibros() {

		return jdbcTemplate.query("select * from libro", new LibroMapper());

	}

	@Override
	@Transactional(readOnly = true)
	public LibroVO findByTituloIgnoreCaseContaining(String titulo) {

		respuesta = new LibroVO("Ha ocurrido un error!", "104", new ArrayList<Libro>());

		try {
			List<Libro> libro = (List<Libro>) dao.findByTituloIgnoreCaseContaining(titulo);
			if (libro.size() > 0) {
				respuesta.setLibros(libro);
				respuesta.setMensaje("Se ha encontrado el libro");
				respuesta.setCodigo("0");
			} else {
				respuesta.setMensaje("No se ha encontrado el libro");
				respuesta.setCodigo("104");
			}
		} catch (Exception e) {
			logger.error("Error al buscar el libro", e);
		}

		return respuesta;
	}

	@Override
	@Transactional(readOnly = true)
	public LibroVO findByAutorIgnoreCaseContaining(String autor) {

		respuesta = new LibroVO("Ha ocurrido un error!", "104", new ArrayList<Libro>());

		try {
			List<Libro> libro = (List<Libro>) dao.findByAutorIgnoreCaseContaining(autor);
			if (libro.size() > 0) {
				respuesta.setLibros(libro);
				respuesta.setMensaje("Se ha encontrado el libro");
				respuesta.setCodigo("0");
			} else {
				respuesta.setMensaje("No se ha encontrado el libro");
				respuesta.setCodigo("104");
			}
		} catch (Exception e) {
			logger.error("Error al buscar el libro", e);
		}

		return respuesta;
	}
	
	/********************************************************************************************/

	/* @Override
	public LibroVO findByAutorIgnoreCaseContaining(String autor) {

		respuesta = new LibroVO("Ha ocurrido un error!", "104", new ArrayList<Libro>());

		try {
			List<Libro> libro = dao.findByAutorIgnoreCaseContaining(autor);
			System.out.println(libro);
			if (libro.size() > 0) {
				respuesta.setLibros(libro);
				respuesta.setMensaje("Se ha encontrado el libro");
				respuesta.setCodigo("0");
			} else {
				respuesta.setMensaje("No se ha encontrado el libro");
				respuesta.setCodigo("104");
			}
		} catch (Exception e) {
			logger.error("Error al buscar el libro", e);
		}
		
		return respuesta;
	} */
	
	/********************************************************************************************/

}
