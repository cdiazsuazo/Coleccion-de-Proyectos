package cl.desafiolatam.bibliotecabooklet.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import cl.desafiolatam.bibliotecabooklet.modelo.Libro;

public class LibroMapper implements RowMapper<Libro> {
	
	@Override
	public Libro mapRow(ResultSet resultSet, int i) throws SQLException {
		
		Libro libro = new Libro();
		
		libro.setId_libro(resultSet.getInt("id_libro"));
		libro.setTitulo(resultSet.getString("titulo"));
		libro.setAnno(resultSet.getString("anno"));
		libro.setAutor(resultSet.getString("autor"));
		libro.setImprenta(resultSet.getString("imprenta"));
		libro.setDisponible(resultSet.getString("disponible"));
		
		return libro;
		
	}

}
