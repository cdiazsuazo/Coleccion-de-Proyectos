package cl.desafiolatam.bibliotecabooklet.service;

import java.util.List;

import cl.desafiolatam.bibliotecabooklet.modelo.Libro;
import cl.desafiolatam.bibliotecabooklet.vo.LibroVO;

public interface LibroService {
	
	public LibroVO add(Libro libro);
	public LibroVO delete(Libro libro);
	public LibroVO update(Libro libro);
	public LibroVO findById(int id);
	public List<Libro> getAllLibros();
	public LibroVO findByTituloIgnoreCaseContaining(String titulo);
	public LibroVO findByAutorIgnoreCaseContaining(String autor);
	
	/********************************************************************************************/

	//public LibroVO findByAutorIgnoreCaseContaining(String autor);
	
	/********************************************************************************************/

}
