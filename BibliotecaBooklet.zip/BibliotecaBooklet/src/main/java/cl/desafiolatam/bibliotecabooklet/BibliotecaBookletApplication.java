package cl.desafiolatam.bibliotecabooklet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaBookletApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaBookletApplication.class, args);
	}

}
