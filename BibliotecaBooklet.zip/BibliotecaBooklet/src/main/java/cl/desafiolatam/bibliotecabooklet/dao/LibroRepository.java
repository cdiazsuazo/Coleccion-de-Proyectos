package cl.desafiolatam.bibliotecabooklet.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import cl.desafiolatam.bibliotecabooklet.modelo.Libro;

public interface LibroRepository extends CrudRepository<Libro, Integer> {
	
	//@Query(value = "select * from libro where titulo=?1", nativeQuery=true)
	public List<Libro> findByTituloIgnoreCaseContaining(String titulo);
	
	//@Query(value = "select * from libro where autor=?1", nativeQuery=true)
	public List<Libro> findByAutorIgnoreCaseContaining(String autor);
	
	/********************************************************************************************/
	
	//@Query(value = "select * from libro where autor like %:patron%", nativeQuery=true)
	//public List<Libro> findByAutorIgnoreCaseContaining(String autor);
	
	/********************************************************************************************/

}
