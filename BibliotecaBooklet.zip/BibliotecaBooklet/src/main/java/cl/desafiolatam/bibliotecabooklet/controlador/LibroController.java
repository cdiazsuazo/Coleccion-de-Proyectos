package cl.desafiolatam.bibliotecabooklet.controlador;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import cl.desafiolatam.bibliotecabooklet.modelo.Libro;
import cl.desafiolatam.bibliotecabooklet.service.LibroService;
import cl.desafiolatam.bibliotecabooklet.vo.LibroVO;

@Controller
public class LibroController {

	private final static Logger logger = LoggerFactory.getLogger(LibroController.class);

	@Autowired
	private LibroService svc;

	@GetMapping({ "/", "/bibliotecabooklet" })
	public String listarLibros(Model model, @RequestParam(defaultValue = "1") int p) {

		model.addAttribute("listaLibros", svc.getAllLibros());
		return "home";
	}

	@GetMapping("/eliminar")
	public ModelAndView eliminarLibro(Model model, @RequestParam String idLibro, RedirectAttributes ra) {

		LibroVO respuestaServicio = new LibroVO();
		respuestaServicio.setMensaje("No fue posible eliminar el libro");

		try {
			Libro libroEliminar = new Libro();
			libroEliminar.setId_libro(Integer.parseInt(idLibro));
			respuestaServicio = svc.delete(libroEliminar);
			return new ModelAndView("redirect:/bibliotecabooklet");
		} catch (Exception e) {
			logger.error("Error al eliminar el libro", e);
		}

		respuestaServicio = (LibroVO) svc.getAllLibros();
		ra.addAttribute("listaLibros", respuestaServicio);

		return new ModelAndView("redirec:/bibliotecabooklet");
	}

	@GetMapping({ "/buscar" })
	public ModelAndView buscarLibro(Model model, @RequestParam String tituloLibro) {

		if (tituloLibro.equals("")) {
			return new ModelAndView("redireccionerror");
		} else {
			LibroVO respuestaServicio = new LibroVO();
			respuestaServicio.setMensaje("No se ha encontrado el registro");

			try {
				respuestaServicio = svc.findByTituloIgnoreCaseContaining(tituloLibro);
				model.addAttribute("libroResultado", respuestaServicio.getLibros());
				return new ModelAndView("resultadotitulo");
			} catch (Exception e) {
				logger.error("Error al encontrar el libro");
			}

			return new ModelAndView("redirect:/bibliotecabooklet");
		}
	}

	@GetMapping({ "/buscarAutor" })
	public ModelAndView buscarAutor(Model model, @RequestParam String autorLibro) {

		if (autorLibro.equals("")) {
			return new ModelAndView("redireccionerror");
		} else {
			LibroVO respuestaServicio = new LibroVO();
			respuestaServicio.setMensaje("No se ha encontrado el registro");

			try {
				respuestaServicio = svc.findByAutorIgnoreCaseContaining(autorLibro);
				model.addAttribute("autorResultado", respuestaServicio.getLibros());
				return new ModelAndView("resultadoautor");
			} catch (Exception e) {
				logger.error("Error al encontrar el libro");
			}

			return new ModelAndView("redirect/bibliotecabooklet");
		}
	}
	
	/********************************************************************************************/
	
	/* @GetMapping({ "/buscarAutorPatron" })
	public ModelAndView buscarAutorPatron(Model model, @RequestParam String autorLibro) {

			LibroVO respuestaServicio = new LibroVO();
			respuestaServicio.setMensaje("No se ha encontrado el registro");

			try {
				respuestaServicio = svc.findByAutorIgnoreCaseContaining(autorLibro);
				model.addAttribute("autorResultado", respuestaServicio.getLibros());
				return new ModelAndView("resultadopatron");
			} catch (Exception e) {
				logger.error("Error al encontrar el libro");
			}

			return new ModelAndView("redirect/bibliotecabooklet");
		} */
	
	/********************************************************************************************/

	@GetMapping("/editarForm")
	public ModelAndView editarForm(Model model, @RequestParam String idLibro) {

		LibroVO respuestaServicio = new LibroVO();
		respuestaServicio.setMensaje("No se puede acceder a la pagina de edicion");

		try {
			Integer id = Integer.parseInt(idLibro);
			respuestaServicio = svc.findById(id);
			model.addAttribute("listaLibros", respuestaServicio.getLibros().get(0));
			return new ModelAndView("editar");
		} catch (Exception e) {
			logger.error("Error al editar el libro");
		}

		respuestaServicio = (LibroVO) svc.getAllLibros();
		return new ModelAndView("redirect:/bibliotecabooklet");
	}

	@GetMapping("/editarDisponibilidad")
	public ModelAndView editarDisponibilidad(Model model, @RequestParam String idLibro) {

		LibroVO respuestaServicio = new LibroVO();
		respuestaServicio.setMensaje("No se puede acceder a la pagina de edicion");

		try {
			Integer id = Integer.parseInt(idLibro);
			respuestaServicio = svc.findById(id);
			model.addAttribute("listaLibros", respuestaServicio.getLibros().get(0));
			return new ModelAndView("editardisponibilidad");
		} catch (Exception e) {
			logger.error("Error al editar el libro");
		}

		respuestaServicio = (LibroVO) svc.getAllLibros();
		return new ModelAndView("redirect:/bibliotecabooklet");
	}

	@PostMapping("/editar")
	public ModelAndView editar(@ModelAttribute Libro libro) {

		LibroVO respuestaServicio = svc.update(libro);

		if (respuestaServicio.getCodigo().equals("0")) {
			return new ModelAndView("redirect:/bibliotecabooklet");
		} else {
			return new ModelAndView("redirect:/error");
		}
	}

	@PostMapping("/agregar")
	public ModelAndView agregarLibro(@ModelAttribute Libro libro) {

		LibroVO respuestaServicio = svc.add(libro);

		if (respuestaServicio.getCodigo().equals("0")) {
			return new ModelAndView("redirect:/bibliotecabooklet");
		} else {
			return new ModelAndView("redirect:/error");
		}
	}

}
