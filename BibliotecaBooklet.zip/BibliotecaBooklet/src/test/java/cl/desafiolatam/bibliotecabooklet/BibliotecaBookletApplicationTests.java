package cl.desafiolatam.bibliotecabooklet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaBookletApplicationTests {

	@Test
	void contextLoads() {
	}

}
