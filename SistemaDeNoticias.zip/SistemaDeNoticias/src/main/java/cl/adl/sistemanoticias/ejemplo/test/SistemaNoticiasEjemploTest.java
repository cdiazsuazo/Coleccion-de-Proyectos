package cl.adl.sistemanoticias.ejemplo.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;

public class SistemaNoticiasEjemploTest {
	
	@Test
	public void readFile() {
		try {
			String file = "src/main/resources/noticias.txt";
			
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String lineaActual = reader.readLine();
			ArrayList<String> datosDeArchivo = new ArrayList<String>();
			
			while(lineaActual != null) {
				datosDeArchivo.add(lineaActual);
				lineaActual = reader.readLine();
			}
			
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
