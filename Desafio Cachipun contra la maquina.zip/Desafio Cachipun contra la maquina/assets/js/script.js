
var numPartida = parseInt(prompt("Cuantas veces quiere jugar"));

nombreInicio(numPartida);

function nombreInicio(numPartida2) {

    if (numPartida2 >= 1) {

        cachipun(numPartida2);

    } else {

        alert("Ingreso valor erroneo, no se puede iniciar la partida");

        return false;

    }


}

function cachipun(cantidad) {

    for (var i = 0; i < cantidad; i++) {

        var jugada = jugadaUsuario();
        var computadora = jugadaComputadora();

        resultado(jugada, computadora);

    }
}


function jugadaUsuario() {

    var marca = false;

    do {
        let mano = parseInt(prompt("Elija 1, para piedra - elija 2, para papel - Elija 3, para tijera"));

        switch (mano) {

            case 1:
                var eleccion = mano;
                marca = true;
                break;

            case 2:
                var eleccion = mano;
                marca = true;
                break;

            case 3:
                var eleccion = mano;
                marca = true;
                break;

            default:
                alert("Por favor, elija una opcion correcta");
                break;

        }


    } while (!marca);

    return eleccion;

}

function jugadaComputadora() {

    alert("Ahora jugara la Computadora");

    var robot = Math.floor(Math.random() * 3) + 1;

    switch (robot) {

        case 1:
            alert("La computadora elijio Piedra");
            break;

        case 2:
            alert("La computadora elijio Papel");
            break;
        case 3:
            alert("La computadora elijio Tijera");
            break;

    }
    return robot;
}


function resultado (player,computer){

    if(player === computer){

        alert("Se a generado un Empate");

    }
    else if(player === 1 && computer === 2){
        alert("La computadora Gano");
        
    }
    else if(player === 1 && computer === 3){

        alert("Felicidades, Tu Ganas");
    }
    else if(player === 2 && computer === 3){
        alert("La computadora Gano");
        
    }
    else if(player === 2 && computer === 1){

        alert("Felicidades, Tu Ganas");
    }
    else if(player === 3 && computer === 1){
        alert("La computadora Gano");
        
    }
    else if(player === 3 && computer === 2){

        alert("Felicidades, Tu Ganas");
    }


}




