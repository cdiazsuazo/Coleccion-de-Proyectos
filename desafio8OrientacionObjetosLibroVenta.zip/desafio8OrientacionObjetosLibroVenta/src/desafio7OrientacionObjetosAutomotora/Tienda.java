package desafio7OrientacionObjetosAutomotora;

public class Tienda {
	
	private Vendedor vendedor;
	private Vehiculo vehiculo;
	private int stock;
	
	//constructor
	public Tienda (Vendedor vendedor, Vehiculo vehiculo, int stock) {
		this.vendedor = vendedor;
		this.vehiculo = vehiculo;
		this.stock =stock;
			
	}
	
	public Tienda() {
		
	}	

	public Vendedor getVendedor() {
		return vendedor;
	}

	public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
	}

	public Vehiculo getVehiculo() {
		return vehiculo;
	}

	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}
	
	//metodo "existeStock" y que retorna "stock"
	public String existeStock(int stock) {
		if(stock > 0) {
			return "cantidad de stock es: " + stock;
			
		}else {
			
		return null;
		
		}
		
		
	}

}
