package desafio7OrientacionObjetosAutomotora;

public class MiniBus extends Bus{

	//atributo
	private String tipoViaje;

	//constructor del metodo extendido Vehiculo y se agrega el atributo tipoViaje solo para miniBus
	public MiniBus(String color, String patente, int cantidadDeAsiento, String tipoViaje) {
		super(color, patente, cantidadDeAsiento );
		this.tipoViaje = tipoViaje;
	}

	public MiniBus() {

	}

	public String getTipoViaje() {
		return tipoViaje;
	}

	public void setTipoViaje(String tipoViaje) {
		this.tipoViaje = tipoViaje;
	}

	
	

	public String  imprimeBus() {
		
		System.out.println(getTipoViaje());
		return tipoViaje;
		
		
		
	}

	@Override
	public String toString() {
		return "miniBus [tipoViaje=" + tipoViaje + ", getColor()=" + getColor() + ", getPatente()=" + getPatente()
				+ "]";
	}


	
}



