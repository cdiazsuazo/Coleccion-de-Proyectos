package desafio7OrientacionObjetosAutomotora;

public class Cliente extends Persona {//metodo extendido o con herencia desde Persona
	
	//constructor del metodo extendido Persona y se agrega los atributos nombre, rut y edad
	public Cliente(String nombre, String rut, int edad) {
		super(nombre, rut, edad);
		
		}
	
		
	public Cliente(int edad) {
		super(null, null, edad);
		
	}
	
	public Cliente() {
		
	}


}
