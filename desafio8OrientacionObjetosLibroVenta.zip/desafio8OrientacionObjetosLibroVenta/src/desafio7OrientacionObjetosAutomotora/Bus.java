package desafio7OrientacionObjetosAutomotora;

public class Bus extends Vehiculo { //metodo extendido o con herencia desde Vehiculos
	//atributo solo para clase bus
		protected int cantidadDeAsiento;
		
	//constructor del metodo extendido Vehiculo y se agrega los atributos color y patente
	public Bus(String color, String patente, int cantidadDeAsiento) {
		super(color, patente);
		this.cantidadDeAsiento = cantidadDeAsiento;
	}
		

	public int getCantidadDeAsiento() {
		return cantidadDeAsiento;
	}
	
	public Bus() {
		
	}

	public void setCantidadDeAsiento(int cantidadDeAsiento) {
		this.cantidadDeAsiento = cantidadDeAsiento;
	}
	// metodo para retornar asientos disponibles
	public int asientoDisponible(int ocupados ) {
		if(ocupados<cantidadDeAsiento) {
			int disponible = (cantidadDeAsiento - ocupados);
			return disponible;
		}
		else {
			System.out.println("Sin Asientos Disponibles"); 
			
			return ocupados;
		}
		
	}
	

}
