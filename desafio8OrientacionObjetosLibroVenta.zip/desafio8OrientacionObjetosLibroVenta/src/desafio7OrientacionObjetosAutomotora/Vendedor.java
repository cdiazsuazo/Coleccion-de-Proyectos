package desafio7OrientacionObjetosAutomotora;

public class Vendedor extends Persona {//metodo extendido o con herencia desde Persona
	
	//constructor del metodo extendido Persona y se agrega los atributos nombre, rut y edad
	public Vendedor (String nombre, String rut, int edad) {
		super (nombre, rut, edad);
		
	}
	//atributo solo para la clase Vendedor
	private String direccion;
	
	public Vendedor(String direccion) {
		this.direccion = direccion;
		
	}
	
	public Vendedor() {
		
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	
	

}
