package desafio7OrientacionObjetosAutomotora;

import java.io.File; 
import java.io.FileWriter;
import java.io.IOException;


public class LibroVenta {
	//esta clase trabaja con patente de vehiculo, la edad de cliente la fecha y el nombre de la venta
	public String nombreVenta;
	public String fechaVenta;
	public Cliente cliente;
	public Vehiculo vehiculo;
	
	/**
	 * @param nombreVenta
	 * @param fechaVenta
	 * constructor
	 */
	//esto es el constructor
	public LibroVenta(String nombreVenta, String fechaVenta, Cliente cliente, Vehiculo vehiculo) {
		super();
		this.nombreVenta = nombreVenta;
		this.fechaVenta = fechaVenta;
		this.cliente = cliente;
		this.vehiculo = vehiculo;
		
	}
	public LibroVenta() {
		
	}
	
	/**
	 * @return the nombreVenta
	 */
	public String getNombreVenta() {
		return nombreVenta;
	}
	/**
	 * @param nombreVenta the nombreVenta to set
	 */
	public void setNombreVenta(String nombreVenta) {
		this.nombreVenta = nombreVenta;
	}
	/**
	 * @return the fechaVenta
	 */
	public String getFechaVenta() {
		return fechaVenta;
	}
	/**
	 * @param fechaVenta the fechaVenta to set
	 */
	public void setFechaVenta(String fechaVenta) {
		this.fechaVenta = fechaVenta;
	}
	
	public File crearArchivo() {
		String rutaDirectorio = "src/fichero";
		String rutaArchivo = rutaDirectorio + "/" + nombreVenta + ".txt";
		
		File directorio = new File(rutaDirectorio);
		File archivo = new File(rutaArchivo);
		
			
		if (!directorio.exists()) {
			directorio.mkdir();
			
			try {
				if(!archivo.exists()) {
					archivo.createNewFile();
					return archivo;
				}
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
			else {
				try {
					if(!archivo.exists()) {
						archivo.createNewFile();
						return archivo;
					}
			}
				catch (IOException e) {
					e.printStackTrace();
				}
			
		}
		
		return archivo;
		
	}
	
	public void guardarVenta() {
		File archivo = crearArchivo();
		
		String patenteVehiculo = vehiculo.getPatente();
        int edadCliente = cliente.getEdad();
 
        try {
            FileWriter wr = new FileWriter(archivo);
            wr.write("Patente veh�culo: " + patenteVehiculo + ", Edad Cliente: " + edadCliente + ", Fecha venta: " +
                    fechaVenta + ", Nombre de venta: " + nombreVenta + "\n");
            wr.close();
 
        } catch (IOException e) {
            e.printStackTrace();
        }
		
	}

}
