package EjercicioIndianaJeans;

/**
 * 
 * @author Cristian Diaz
 *
 */

import java.util.List;

/**
 * 
 * @author Cristian Diaz
 *
 */

public abstract class Exportador {

	public  void exportar (String nombreArchivo, String ruta, List<Producto> listaProductos) {
		
		
	}

}
