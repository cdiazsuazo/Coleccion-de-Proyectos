
validar();

function validar(){

    var limite = parseInt(prompt("ingrese numero del 1 al 20"));



    if(limite > 1 && limite < 20){

        for(var i = 1; i<= limite; i++){

            let multiplicacion = (i, limite) => console.log("%cMutliplicacion " + i + " x " + limite + " = " + i*limite,"color:#0B5345;font-size: 16px;background:#76D7C4;font-weight: bold;");

            multiplicacion(i, limite);

            
        }

        for(var j=1; j<=limite; j++){
            var miFact = factorial(j);
            console.log("%cEl factorial de " + j + " = " + miFact,"color:#A9CCE3;font-size: 16px;background:#9C640C;font-weight: bold;");
        }


    }else{

        alert("Numero fuera de rango, ingrese numero correcto");
    }

    function factorial(contador){
   
        if (contador > 1) {
    
            return contador * factorial(contador - 1);  // n! = n*(n-1)!
    
        } else {
            return contador;
        }
    

}

}
