package desafio11MirandoElPasado;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class MirandoElPasado {

	public static void main(String[] args) {
		
		System.out.println("*************************************************Desafio List*******************************************************\n");	
		
List<String> marcas = new ArrayList<>();// creamos una Arraylist de Lista "marca"
		
		/*
		 * Agregamos marcas a la lista "marcas"
		 */
		
		marcas.add("Free");
		marcas.add("Dos en Uno");
		marcas.add("Life");
		marcas.add("Hilton");
		marcas.add("Capel");
		marcas.add("Negrita");
		marcas.add("Rinso");
		marcas.add("Sapolio");
		marcas.add("Sapito");
		marcas.add("Power");
		
		
		System.out.println("--------------Impresion de ArrayList Marcas--------------");
		
		System.out.println(marcas);
		
		System.out.println("\n");
		
		
		/*
		 * se crea un nuevo ArrayList de List MasMarcas
		 */
		
		List<String> masMarcas = new ArrayList<>();
		
		masMarcas.add("Blokbaster");
		masMarcas.add("Carrefour");
		masMarcas.add("Jetix");
		
		marcas.addAll(masMarcas);//agregamos todo el contenido de ArrayList "masMarcas" al ArrayList "marcas"
		
		System.out.println("--------------Impresion de Nuevas Marcas agregadas a ArrayList Marcas--------------");
		
		System.out.println(marcas);
		
		System.out.println("\n");
		
		marcas.set(10, "Blockbuster");//con set reemplazamos de la posicion 10 a Blokbaster por la palabra cortrecta Blockbuster
		
		System.out.println("--------------Impresion de cambio de marca Blockbuster--------------");
		System.out.println(marcas);
		
		System.out.println("\n");
		
		System.out.println("--------------Impresion de Booleano al remover marca Carrefour--------------");				
		System.out.println(marcas.remove("Carrefour"));//removemos la marca Carrefour e imprimimos un boolean si es eliminado que  en este caso es True
		
		System.out.println("\n");
		
		System.out.println("--------------Impresion sin la marca Carrefour--------------");
		
		System.out.println(marcas);
		
		System.out.println("\n");
		
		
		List<String> PosiblesMarcas = new ArrayList<>();//creamos otro ArrayList "PosiblesMarcas" y agregamos otras marcas que psiblemente esten fuera de mercado
		
		PosiblesMarcas.add("Yoguito");
		PosiblesMarcas.add("MitiMiti");
		PosiblesMarcas.add("Zuko");
		PosiblesMarcas.add("Yupi");
		
		marcas.addAll(PosiblesMarcas);//Agregamos el contenido del ArrayList "PosiblesMarcas" al ArrayList "marcas"
		
		System.out.println("--------------Impresion de Nuevas PosiblesMarcas agregadas a ArrayList Marcas--------------");
		
		System.out.println(marcas);
		
		System.out.println("\n");
		
		System.out.println("--------------Impresion de cantidad de elementos de ArrayList Marcas--------------");
		
		System.out.println(marcas.size());//con size imprimimos la cantidad de registros que tiene el ArrayList "marcas"
		System.out.println("\n");
		
		
		
		System.out.println("*************************************************Desafio Set*******************************************************\n");
		
Set<String> invitados = new TreeSet<>();//TreeSet almacena como un arbol es decir, ordena sus elementos en funci�n de sus valores.
		
		/**
		 * Agregamos Invitados a la lista invitados
		 */
		
		invitados.add("Daniel");
		invitados.add("Paola");
		invitados.add("Facundo");
		invitados.add("Pedro");
		invitados.add("Jacinta");
		invitados.add("Florencia");
		invitados.add("Juan Pablo");
		
		
		Set<String> posiblesInvitados = new TreeSet<>();//TreeSet almacena como un arbol es decir, ordena sus elementos en funci�n de sus valores.
		
		/*
		 * Agregamos nuevos invitados a la nueva lista posiblesInvitados
		 */
		
		posiblesInvitados.add("Jorge");
		posiblesInvitados.add("Francisco");
		posiblesInvitados.add("Marcos");
		
		invitados.addAll(posiblesInvitados);// Agregamos los datos de lista "posiblesInvitados" a la lista "invitados"
		
		System.out.println("--------------Impresion de lista invitados con los 3 posibles nuevos invitados de listaPosiblesInvitados --------------");
		
		System.out.println(invitados);
		
		System.out.println("\n");
		
		System.out.println("--------------Impresion de lista Final con remocion de Jorge--------------");
		
		invitados.remove("Jorge");// eliminamos o removemos a "Jorge" de la lista "invitados"
		
		System.out.println("Listado Final de Invitados:  " + invitados);
		
		System.out.println("\n");
		
		
		System.out.println("*************************************************Desafio Map*******************************************************\n");
		
Map<String, Integer> golosinas = new TreeMap<>();// con map asignamos una clave(key) y un valor(value) y no admite duplicados y con Treemap ordena de forma alfabetica
		
		/*
		 * agregamos las golosinas popn put
		 */
		
		golosinas.put("Chocman", 100);
		golosinas.put("Trululu", 100);
		golosinas.put("Centella", 100);
		golosinas.put("Kilate", 50);
		golosinas.put("Miti-miti", 30);
		golosinas.put("Traga Traga", 150);
		golosinas.put("Tableton", 5);
		
		System.out.println("--------------Impresion de lista golosinas--------------");
		
		System.out.println(golosinas);
		
		System.out.println("\n");
		
		System.out.println("--------------Impresion de lista golosinas que cuestan menores a 100 pesos--------------");
		
		System.out.println("Estas Golosinas cuetan menos de 100 pesos: ");
		
		
		
		/*
		 * con entrySet devolvemos la vista tipo Set que contien todas las claves y valores
		 * con forEach recorremos toda la cola y se imprimen los elementos que cumplan con lo establecido en filter
		 * asi  filtramos las golosinas menores a 100 pesos e imprimimos
		 */
		
		golosinas.entrySet().stream().filter(preciosbajos -> preciosbajos.getValue()<100).forEach(System.out::print);
		
		System.out.println("\n");
		
		
		System.out.println("*************************************************Desafio Queue*******************************************************\n");
		
		Queue<String> juegos = new LinkedList<>();// "creamos un Queue para guarda los juegos en una  cola y Queue permite duplicados
		
		/*
		 * Agregamos juegos a la Cola
		 */
		
		juegos.add("Tombo");
		juegos.add("Congelado");
		juegos.add("Quemaditas");
		juegos.add("Cachipun");
		juegos.add("Pillarse");
		
		System.out.println("-------Juegos en Cola--------\n");
		
			
		System.out.println("La cantidad de juegos hasta el momento es:  " + juegos.size());// con size determinamos el tama�o de la cola o la cantidad de juegos en ella 
		
		System.out.println("\n");
		
		System.out.println("Y son los Siguientes:  " + juegos);
		
	}

		

	}


