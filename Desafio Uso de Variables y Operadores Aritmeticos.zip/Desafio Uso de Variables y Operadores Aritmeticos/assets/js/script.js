
document.write(  " <font color='blue'> <h4> OPERACIONES DE SUMA-RESTA-DIVISION-MULTIPLIOCACION-MODULO </h4> </font>" + "<br>" )

// Se pide ingresar dos variables con sus respectivos valores
var numero1 = parseInt(prompt (" Ingresar primer numero"));
var numero2 = parseInt(prompt (" Ingresar segundo numero"));

// Se realizan las operaciones matematicas con  ambas variables y el resultado se guarda en una nueva variable definida para cada operacion
var suma = numero1 + numero2;
var resta = numero1 - numero2;
var multiplicacion = numero1 * numero2;
var division = numero1 / numero2;
var modulo = numero1 % numero2;

// Se muestra el resultado  de las operaciones en la pagina HTML
document.write("La Suma es: --> " + suma + "<br>");

document.write("La resta es: --> " + resta + "<br>");

document.write("La multiplicacion es: --> " + multiplicacion + "<br>");

document.write("La Division es: --> " + division + "<br>");

document.write("El Modulo es: --> " + modulo + "<br>");


/************************************************************************************** */
document.write(" <font color='blue'> <h4> CONVERSION DE GRADOS CELCIUS A KELVIN Y FAHRENHEIT </h4> </font>" + "<br>" )

// Se pide ingresar una variable o grados
var grados = parseInt(prompt (" Ingresar temperatura en grados Celsius"));

// se parsea y transforman los grados a Kelvin y Fahrenheit y se guardan en variables
var Kelvin = parseFloat(grados + 273.15);
var Fahrenheit = parseFloat ((grados * 9/5) + 32);

// Se muestra el resultado  de las operaciones en la pagina HTML
document.write(" Los grados Kelvin son: --> " + Kelvin + "<br>");

document.write(" Los grados Fahrenheit son: --> " + Fahrenheit + "<br>");

/************************************************************************************** */
document.write(" <font color='blue'> <h4> CONVERSION DE LOS DIAS INGRESADOS EN AÑOS-SEMANAS-DIAS </h4> </font>" + "<br>")

// Se pide ingresar los dias a calcular
var dias = parseInt(prompt (" Ingresar dias a calcular"));

// se se calcula con math.floor y se parsea a años dias y semanas 
var anios = parseInt(Math.floor(dias/365));
var dias2 = dias - 365 * anios;
var semanas = parseInt(Math.floor(dias2 / 7));
var dias3 = dias2 - 7 * semanas;

// Se muestra el resultado  de las operaciones en la pagina HTML
document.write("Los dias ingresados corresponden a: --> " + anios + "Años" + "<br>");
document.write("Los dias ingresados corresponden a: --> " + semanas + "Semanas" + "<br>");
document.write("Los dias ingresados corresponden a: --> " + dias3 + "dias" +"<br>");


/************************************************************************************** */
document.write(" <font color='blue'> <h4> SUMA Y PROMEDIO DE NUMEROS INGRESADOS </h4> </font>" + "<br>")

// Se pide ingresar 5 numeros para realizar las operaciones
var num1 = parseInt(prompt (" Ingresar primer numero"));
var num2 = parseInt(prompt (" Ingresar segundo numero"));
var num3 = parseInt(prompt (" Ingresar tercer numero"));
var num4 = parseInt(prompt (" Ingresar cuarto numero"));
var num5 = parseInt(prompt (" Ingresar quinto numero"));

var gransuma = num1 + num2 + num3 + num4 + num5;
var promedio = gransuma / 5;

document.write("La suma total de los valores ingresados es: --> " + gransuma + "<br>");
document.write("El promedio de los valores ingresados es: --> " + promedio + "<br>");





