package cl.desafiolatam.imdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaImDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
