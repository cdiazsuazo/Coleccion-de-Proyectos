package desafio7OrientacionObjetosAutomotora;

public class miniBus extends Vehiculo{

	//atributo
	private String tipoViaje;

	//constructor del metodo extendido Vehiculo y se agrega el atributo tipoViaje solo para miniBus
	public miniBus(String color, String patente, String tipoViaje) {
		super(color, patente);
		this.tipoViaje = tipoViaje;
	}

	public miniBus() {

	}

	public String getTipoViaje() {
		return tipoViaje;
	}

	public void setTipoViaje(String tipoViaje) {
		this.tipoViaje = tipoViaje;
	}

	
	

	public String  imprimeBus() {
		
		System.out.println(getTipoViaje());
		return tipoViaje;
		
		
		
	}

	@Override
	public String toString() {
		return "miniBus [tipoViaje=" + tipoViaje + ", getColor()=" + getColor() + ", getPatente()=" + getPatente()
				+ "]";
	}


	
}



