package desafio7OrientacionObjetosAutomotora;

public class Taxi extends Vehiculo{//metodo extendido o con herencia desde Vehiculos
	
	
	//constructor del metodo extendido Vehiculo y se agrega los atributos color y patente
	public Taxi(String color, String patente) {
		super(color, patente);
		
	}
	//atributo solo para clase taxi
	private int valorPasaje;
	
	public Taxi (int valorPasaje) {
		this.valorPasaje = valorPasaje;
	}
	
	public Taxi() {
		
	}

	public int getValorPasaje() {
		return valorPasaje;
	}

	public void setValorPasaje(int valorPasaje) {
		this.valorPasaje = valorPasaje;
	}
	// metodo para retornar vuelto o valor pagado
	public int pagarPasaje(int valorPagado) {
		if (valorPagado>valorPasaje) {
			int vuelto = (valorPagado - valorPasaje);
			
			return  vuelto;
		}
		else {
			return  valorPagado;
		}
		
	}
	
	
}
