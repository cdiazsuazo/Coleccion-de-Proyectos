package desafio7OrientacionObjetosAutomotora;


public class AutomotoraLatam {

	public static void main(String[] args) {
		
		miniBus miMiniBus = new miniBus();
				
		miMiniBus.setColor("Amarillo");
		miMiniBus.setPatente("ddyd33");
		miMiniBus.setTipoViaje("General");
		
		Taxi miTaxi = new Taxi();
		miTaxi.setValorPasaje(500);
		
		Bus miBus = new Bus();
		miBus.setCantidadDeAsiento(30);
		
		Tienda miTienda = new Tienda();
		miTienda.existeStock(0);
		
		
		System.out.println("Clase Taxi: " + miTaxi.pagarPasaje(600));
		
		System.out.println("Clase Bus: " + miBus.asientoDisponible(25));
				
		System.out.println("Clase MiniBus:" + miMiniBus.toString());
		
		System.out.println("Clase Tienda: " + miTienda.existeStock(30));

	}

}
