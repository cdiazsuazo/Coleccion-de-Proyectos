package cl.desafiolatam.logistiqal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogistiqalApplicationTests {

	@Test
	void contextLoads() {
	}

}
