package cl.desafiolatam.logistiqal.service;

import cl.desafiolatam.logistiqal.modelo.Logistiqal;
import cl.desafiolatam.logistiqal.vo.LogistiqalVO;
import cl.desafiolatam.logistiqal.vo.NumberVO;

public interface LogistiqalService {
	
	public LogistiqalVO add(Logistiqal producto);
	public LogistiqalVO delete(Logistiqal producto);
	public LogistiqalVO update(Logistiqal producto);
	public LogistiqalVO findById(int id);
	public LogistiqalVO findAll();
	public LogistiqalVO findByNombreProductoIgnoreCaseContaining(String producto);
	public LogistiqalVO getPage(Integer pagina, Integer cantidad);
	public NumberVO getPageCount(long registrosPorPagina);

}
