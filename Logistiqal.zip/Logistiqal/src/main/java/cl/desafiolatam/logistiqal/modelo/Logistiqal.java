package cl.desafiolatam.logistiqal.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Logistiqal {
	
	@Id
	@Column(columnDefinition = "NUMERIC(19,0)")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer codigo;
	private String nombreProducto;
	@Column(columnDefinition = "NUMERIC(19,0)")
	private Integer precio;
	@Column(columnDefinition = "NUMERIC(19,0)")
	private Integer stock;
	
	public Integer getCodigo() {
		return codigo;
	}
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	public String getNombre_producto() {
		return nombreProducto;
	}
	public void setNombre_producto(String nombre_producto) {
		this.nombreProducto = nombre_producto;
	}
	public Integer getPrecio() {
		return precio;
	}
	public void setPrecio(Integer precio) {
		this.precio = precio;
	}
	public Integer getStock() {
		return stock;
	}
	public void setStock(Integer stock) {
		this.stock = stock;
	}
	
	@Override
	public String toString() {
		return "Logistiqal [codigo=" + codigo + ", nombre_producto=" + nombreProducto + ", precio=" + precio
				+ ", stock=" + stock + "]";
	}
}
