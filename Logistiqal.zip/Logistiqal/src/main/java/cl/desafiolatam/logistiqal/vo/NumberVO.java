package cl.desafiolatam.logistiqal.vo;

public class NumberVO {
	
	long valor;
	String codigo;
	String mensaje;
	
	public NumberVO(long valor, String codigo, String mensaje) {
		super();
		this.valor = valor;
		this.codigo = codigo;
		this.mensaje = mensaje;
	}
	
	public long getValor() {
		return valor;
	}

	
	public void setValor(long valor) {
		this.valor = valor;
	}

	
	public String getCodigo() {
		return codigo;
	}

	
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	@Override
	public String toString() {
		return "NumberVO [valor=" + valor + ", codigo=" + codigo + ", mensaje=" + mensaje + "]";
	}
	

}
