package cl.desafiolatam.logistiqal.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import cl.desafiolatam.logistiqal.modelo.Logistiqal;
import cl.desafiolatam.logistiqal.service.LogistiqalService;
import cl.desafiolatam.logistiqal.util.Util;
import cl.desafiolatam.logistiqal.vo.LogistiqalVO;

@Controller
public class LogistiqalControlador {

	private final static Logger logger = LoggerFactory.getLogger(LogistiqalControlador.class);

	@Autowired
	private LogistiqalService svc;

	/**********************************
	 * Paginacion
	 *************************************/

	@GetMapping({ "/", "/logistiqal" })
	public String listarProductos(Model model, @RequestParam(defaultValue = "1") int p) {

		Integer totalPaginas = (int) svc.getPageCount(5).getValor();
		model.addAttribute("paginas", Util.getArregloPaginas(p, totalPaginas));
		model.addAttribute("paginasTotales", totalPaginas);
		model.addAttribute("paginaActual", p);
		model.addAttribute("listaProductos", svc.getPage(p - 1, 5));

		return "home";

	}

	/**********************************
	 * Paginacion
	 *************************************/

	@GetMapping({ "/eliminar" })
	public ModelAndView eliminarProducto(Model model, @RequestParam String idProducto, RedirectAttributes ra) {

		LogistiqalVO respuestaServicio = new LogistiqalVO();
		respuestaServicio.setMensaje("No fue posible eliminar el producto");

		try {
			Logistiqal productoEliminar = new Logistiqal();
			productoEliminar.setCodigo(Integer.parseInt(idProducto));
			respuestaServicio = svc.delete(productoEliminar);
			return new ModelAndView("redirect:/logistiqal");
		} catch (Exception e) {
			logger.error("Error al eliminar el producto", e);
		}

		respuestaServicio = svc.findAll();
		ra.addAttribute("listaProductos", respuestaServicio);

		return new ModelAndView("redirect:/logistiqal");

	}

	@GetMapping({ "/buscar" })
	public ModelAndView buscarProducto(Model model, @RequestParam String nombreProducto) {

		if (nombreProducto.equals("")) {
			return new ModelAndView("redireccionerror");
		} else {
			LogistiqalVO respuestaServicio = new LogistiqalVO();
			respuestaServicio.setMensaje("No se ha encontrado el registro");
			try {
				respuestaServicio = svc.findByNombreProductoIgnoreCaseContaining(nombreProducto);
				model.addAttribute("productoResultado", respuestaServicio.getProductos());
				return new ModelAndView("resultadobusqueda");
			} catch (Exception e) {
				logger.error("Error al buscar el producto", e);
			}
		}

		return new ModelAndView("redirect:/logistiqal");

	}

	@GetMapping({ "/editarForm" })
	public ModelAndView editarForm(Model model, @RequestParam String idProducto) {

		LogistiqalVO respuestaServicio = new LogistiqalVO();
		respuestaServicio.setMensaje("No se puede acceder a la pagina de edicion");

		try {
			Integer id = Integer.parseInt(idProducto);
			respuestaServicio = svc.findById(id);
			model.addAttribute("listaProducto", respuestaServicio.getProductos().get(0));
			return new ModelAndView("editar");
		} catch (Exception e) {
			logger.error("Error al editar el producto");
		}

		respuestaServicio = svc.findAll();
		return new ModelAndView("redirect:/logistiqal");
	}

	@PostMapping({ "/editar" })
	public ModelAndView editar(@ModelAttribute Logistiqal producto) {

		LogistiqalVO respuestaServicio = svc.update(producto);

		if (respuestaServicio.getCodigo().equals("0")) {
			return new ModelAndView("redirect:/logistiqal");
		} else {
			return new ModelAndView("redireccionerror");
		}

	}

	@PostMapping({ "/agregar" })
	public ModelAndView agregarProducto(@ModelAttribute Logistiqal producto) {

		if (producto.equals(null)) {
			return new ModelAndView("redirect:/redireccionerror");
		} else {
			LogistiqalVO respuestaServicio = svc.add(producto);

			if (respuestaServicio.getCodigo().equals("0")) {
				return new ModelAndView("redirect:/logistiqal");
			} else {
				return new ModelAndView("redireccionerror");
			}
		}

	}
	
}
