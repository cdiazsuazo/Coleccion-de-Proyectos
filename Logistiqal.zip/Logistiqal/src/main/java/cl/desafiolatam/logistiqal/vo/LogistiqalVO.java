package cl.desafiolatam.logistiqal.vo;

import java.util.List;

import cl.desafiolatam.logistiqal.modelo.Logistiqal;

public class LogistiqalVO extends GenericVisualObject {
	
	List<Logistiqal> productos;

	public LogistiqalVO(String mensaje, String codigo, List<Logistiqal> productos) {
		super(mensaje, codigo);
		this.productos = productos;
	}

	public LogistiqalVO() {
		super();
	}

	public List<Logistiqal> getProductos() {
		return productos;
	}

	public void setProductos(List<Logistiqal> productos) {
		this.productos = productos;
	}

	@Override
	public String toString() {
		return "LogistiqalVO [productos=" + productos + "]";
	}

}
