package cl.desafiolatam.logistiqal.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.desafiolatam.logistiqal.dao.LogistiqalRepository;
import cl.desafiolatam.logistiqal.modelo.Logistiqal;
import cl.desafiolatam.logistiqal.service.LogistiqalService;
import cl.desafiolatam.logistiqal.vo.LogistiqalVO;
import cl.desafiolatam.logistiqal.vo.NumberVO;

@Service
public class LogistiqalServiceImpl implements LogistiqalService {

	private static final Logger logger = LoggerFactory.getLogger(LogistiqalServiceImpl.class);

	@Autowired
	LogistiqalRepository dao;
	LogistiqalVO respuesta;

	@Override
	@Transactional
	public LogistiqalVO add(Logistiqal producto) {

		respuesta = new LogistiqalVO("Ha ocurrido un error!", "104", new ArrayList<Logistiqal>());

		try {
			dao.save(producto);
			respuesta.setMensaje(
					String.format("Se ha añadido correctamente el producto %s", producto.getNombre_producto()));
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.error("Ha ocurrido un error al añadir el producto", e);
		}
		return respuesta;
	}

	@Override
	@Transactional
	public LogistiqalVO delete(Logistiqal producto) {

		respuesta = new LogistiqalVO("Ha ocurrido un error!", "104", new ArrayList<Logistiqal>());

		try {
			dao.delete(producto);
			respuesta.setMensaje(
					String.format("Se ha borrado correctamente el producto %s", producto.getNombre_producto()));
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.error("Ha ocurrido un error al añadir el producto", e);
		}
		return respuesta;

	}

	@Override
	@Transactional
	public LogistiqalVO update(Logistiqal producto) {
		
		respuesta = new LogistiqalVO("Ha ocurrido un error!", "104", new ArrayList<Logistiqal>());

		try {
			dao.save(producto);
			respuesta.setMensaje(
					String.format("Se ha actualizado correctamente el producto %s", producto.getNombre_producto()));
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.error("Ha ocurrido un error al añadir el producto", e);
		}
		return respuesta;
	}

	@Override
	@Transactional(readOnly = true)
	public LogistiqalVO findById(int id) {

		respuesta = new LogistiqalVO("Ha ocurrido un error!", "104", new ArrayList<Logistiqal>());

		try {
			Logistiqal producto = dao.findById(id).get();
			respuesta.getProductos().add(producto);
			respuesta.setMensaje(
					String.format("Se ha actualizado correctamente el producto %s", producto.getNombre_producto()));
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.error("Error al encontrar el registro", e);
		}
		
		return respuesta;
	}

	@Override
	@Transactional(readOnly = true)
	public LogistiqalVO findAll() {
		
		respuesta = new LogistiqalVO("Ha ocurrido un error!", "104", new ArrayList<Logistiqal>());

		try {
			List<Logistiqal> productos = (List<Logistiqal>) dao.findAll();
			respuesta.setProductos(productos);
			respuesta.setMensaje("Se han encontrado los productos");
			respuesta.setCodigo("0");
		} catch (Exception e) {
			logger.error("Error al buscar los registros", e);
		}
		
		return respuesta;
	}

	@Override
	@Transactional(readOnly = true)
	public LogistiqalVO findByNombreProductoIgnoreCaseContaining(String producto) {

		respuesta = new LogistiqalVO("Ha ocurrido un error!", "104", new ArrayList<Logistiqal>());

		try {
			List<Logistiqal> productoPatron = dao.findByNombreProductoIgnoreCaseContaining(producto);
			if (productoPatron.size() > 0) {
				respuesta.setProductos(productoPatron);
				respuesta.setMensaje("Se ha encontrado el producto");
				respuesta.setCodigo("0");
			} else {
				respuesta.setMensaje("No se ha encontrado el registro");
				respuesta.setCodigo("104");
			}
		} catch (Exception e) {
			logger.error("Error al buscar el producto", e);
		}
		
		return respuesta;
	}

	@Override
	@Transactional(readOnly = true)
	public LogistiqalVO getPage(Integer pagina, Integer cantidad) {
		
		respuesta = new LogistiqalVO("Ha ocurrido un error!", "104", new ArrayList<Logistiqal>());
		
		try {
			Pageable pageable = PageRequest.of(pagina, cantidad);
			Page<Logistiqal> responsepage = dao.findAll(pageable);
			respuesta.setProductos(responsepage.getContent());
			respuesta.setMensaje(String.format("Se han encontrado registros %s", respuesta.getProductos().size()));
		} catch (Exception e) {
			logger.error("Error al traer los registros", e);
		}
		
		return respuesta;
	}

	@Override
	@Transactional(readOnly = true)
	public NumberVO getPageCount(long registrosPorPagina) {
		
		NumberVO respuesta = new NumberVO(0, "Ha ocurrido un error", "104");
		
		try {
			long registros = dao.count();
			
			if(registrosPorPagina == 0 && registros == 0) {
				respuesta.setValor(1);
			} else {
				respuesta.setValor((registros/registrosPorPagina) + (registros % registrosPorPagina == 0 ? 0 : 1));
			}
			
			respuesta.setCodigo("201");
			respuesta.setMensaje(String.format("Hay %d paginas", respuesta.getValor()));
		} catch (Exception e) {
			logger.error("Error al contar las paginas", e);
		}
		
		return respuesta;
	}

}
