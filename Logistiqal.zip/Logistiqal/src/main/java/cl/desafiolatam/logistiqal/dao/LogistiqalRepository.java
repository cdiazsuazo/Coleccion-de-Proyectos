package cl.desafiolatam.logistiqal.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.desafiolatam.logistiqal.modelo.Logistiqal;

public interface LogistiqalRepository extends JpaRepository<Logistiqal, Integer> {
	
	public List<Logistiqal> findByNombreProductoIgnoreCaseContaining(String producto);

}
