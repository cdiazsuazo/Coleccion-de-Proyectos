package cl.adl.sistema;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import cl.adl.sistema.dto.Luna;
import cl.adl.sistema.interfaces.impl.ILunaImpl;
import cl.adl.sistema.interfaces.impl.IPlanetaImpl;

class SistemaTest {

	IPlanetaImpl planeta = new IPlanetaImpl();
	ILunaImpl luna = new ILunaImpl();
	Luna lunita = new Luna();
	
	@Test
	void testPlaneta1() {
		InyectarPlaneta p = new InyectarPlaneta(planeta.construirPlaneta("Tierra", "12.756 km.", "149.600.000 km.", "384 400 km.", luna.construirLuna("Luna", "3474 km.", "29 dias")));
		Assertions.assertEquals(1, luna.construirLuna(null, null, null).size());
	}
	
	@Test
	void testPlaneta2() {
		InyectarPlaneta p = new InyectarPlaneta(planeta.construirPlaneta("Mercurio", "4.880 km.", "57.910.000 km.", "no posee lunas", luna.construirLuna(null, null, null)));
		Assertions.assertEquals("Mercurio", p.planeta.getNombre());
		}
	
	@Test
	void testPlaneta3() {
		InyectarPlaneta p = new InyectarPlaneta(planeta.construirPlaneta("Saturno", "tamanio", "1.429.400.000 km", "20.735.000 km.", luna.construirLuna("Aegir", "6 km", "1116,5")));
		lunita.setNombre("Albiorix");
		lunita.setDiametro("30 km");
		lunita.setTiempoOrbita("783");
		p.planeta.getLuna().add(lunita);
		Assertions.assertTrue(!p.planeta.getLuna().isEmpty());
	}
	}
	
	

