package cl.adl.sistema.interfaces.impl;

import java.util.ArrayList;

import cl.adl.sistema.dto.Luna;
import cl.adl.sistema.dto.Planeta;
import cl.adl.sistema.interfaces.IPlaneta;

public class IPlanetaImpl implements IPlaneta {
	
	public Planeta construirPlaneta(String nombre, String tamanio, String distanciaSol, String distanciaLuna, ArrayList<Luna> luna) {
		
		Planeta planeta = new Planeta();
		
		planeta.setNombre(nombre);
		planeta.setTamanio(tamanio);
		planeta.setDistanciaSol(distanciaSol);
		planeta.setDistanciaLuna(distanciaLuna);
		planeta.setLuna(luna);
				
		return planeta;	
	}

}
