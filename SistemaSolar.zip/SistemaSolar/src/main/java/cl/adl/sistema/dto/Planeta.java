package cl.adl.sistema.dto;

import java.util.ArrayList;

public class Planeta {
	
	private String nombre;
	private String tamanio;
	private String distanciaSol;
	private String distanciaLuna;
	private ArrayList<Luna> luna;
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @return the tamanio
	 */
	public String getTamanio() {
		return tamanio;
	}
	/**
	 * @return the distanciaSol
	 */
	public String getDistanciaSol() {
		return distanciaSol;
	}
	/**
	 * @return the distanciaLuna
	 */
	public String getDistanciaLuna() {
		return distanciaLuna;
	}
	/**
	 * @return the luna
	 */
	public ArrayList<Luna> getLuna() {
		return luna;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @param tamanio the tamanio to set
	 */
	public void setTamanio(String tamanio) {
		this.tamanio = tamanio;
	}
	/**
	 * @param distanciaSol the distanciaSol to set
	 */
	public void setDistanciaSol(String distanciaSol) {
		this.distanciaSol = distanciaSol;
	}
	/**
	 * @param distanciaLuna the distanciaLuna to set
	 */
	public void setDistanciaLuna(String distanciaLuna) {
		this.distanciaLuna = distanciaLuna;
	}
	/**
	 * @param luna the luna to set
	 */
	public void setLuna(ArrayList<Luna> luna) {
		this.luna = luna;
	}
	@Override
	public String toString() {
		return "Este es el Planeta " + nombre + ", de tamanio " + tamanio + ", con una distancia al Sol de " + distanciaSol
				+ " y una distancia a su Luna de " + distanciaLuna + ", con las siguientes lunas " + luna;
	}
	
	
	

}
