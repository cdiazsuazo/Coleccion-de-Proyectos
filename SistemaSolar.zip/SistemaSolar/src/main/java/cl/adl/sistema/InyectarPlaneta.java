package cl.adl.sistema;

import cl.adl.sistema.dto.Luna;
import cl.adl.sistema.dto.Planeta;

public class InyectarPlaneta {
	
	Planeta planeta;
	Luna luna;
	
	public InyectarPlaneta(Planeta planeta) {
		this.planeta = planeta;
	}
	
	public boolean enviar() {
		if(planeta.getLuna()==null) {
			System.out.println(planeta + " no posee lunas "); 
		}
		else {
			System.out.println(planeta);
		}
		return true;
	}

}
