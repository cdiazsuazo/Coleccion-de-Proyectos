package cl.adl.sistema;

import cl.adl.sistema.interfaces.impl.IPlanetaImpl;
import cl.adl.sistema.dto.Luna;
import cl.adl.sistema.interfaces.impl.ILunaImpl;

public class SistemaSolar {

	public static void main(String[] args) {
		
		IPlanetaImpl planeta = new IPlanetaImpl();
		ILunaImpl luna = new ILunaImpl();
		Luna lunita = new Luna();
		
		InyectarPlaneta p = new InyectarPlaneta(planeta.construirPlaneta("Mercurio",
				"2439km", "58 millones de kilometros", "no posee lunas", null));
		p.enviar();
		p = new InyectarPlaneta(planeta.construirPlaneta("Venus", "6051km",
				"108 millones de kilometros", "no posee lunas", null));
		p.enviar();
		p = new InyectarPlaneta(planeta.construirPlaneta("Tierra", "6371km",
				"149 millones de kilometros", "Luna: 384 mil km", luna.construirLuna("Luna", "3474km", "29 dias")));
		p.enviar();
		p = new InyectarPlaneta(planeta.construirPlaneta("Marte", "3389km",
				"249 millones de kilometros",
				"Fobos: 9377km, Deimos: 23460km", luna.construirLuna("Fobos", "22533km", "7 horas")));
		lunita.setNombre("Deimos");
		lunita.setDiametro("12.4km");
		lunita.setTiempoOrbita("1 dia");
		p.planeta.getLuna().add(lunita);
		p.enviar();
		p = new InyectarPlaneta(planeta.construirPlaneta("Jupiter",
				"69911km", "750 millones de kilometros",
				"Io: 421 mil km, Europa: 670 mil km", luna.construirLuna("Io", "3643km", "1 dia")));
		lunita.setNombre("Europa");
		lunita.setDiametro("3122km");
		lunita.setTiempoOrbita("3 dias");
		p.planeta.getLuna().add(lunita);
		p.enviar();
		p = new InyectarPlaneta(planeta.construirPlaneta("Saturno",
				"58232km", "1418 millones de kilometros",
				"Atlas: 132 mil km, Prometeo: 139 mil km", luna.construirLuna("Atlas", "32km", "0.60 dias")));
		lunita.setNombre("Prometeo");
		lunita.setDiametro("86km");
		lunita.setTiempoOrbita("0.61 dias");
		p.planeta.getLuna().add(lunita);
		p.enviar();
		p = new InyectarPlaneta(planeta.construirPlaneta("Urano",
				"25362km", "3000 millones de kilometros",
				"Cordelia: 49 mil km, Ofelia: 53 mil km", luna.construirLuna("Cordelia", "26km", "0.33 dias")));
		lunita.setNombre("Ofelia");
		lunita.setDiametro("32km");
		lunita.setTiempoOrbita("0.37 dias");
		p.planeta.getLuna().add(lunita);
		p.enviar();
		p = new InyectarPlaneta(planeta.construirPlaneta("Neptuno", "24622km", "4500 millones de kilometros",
				"Nayade: 48 mil km, Talasa: 50 mil km",
				luna.construirLuna("Nayade", "58km", "0.29 dias")));
		lunita.setNombre("Talasa");
		lunita.setDiametro("80km");
		lunita.setTiempoOrbita("0.31 dias");
		p.planeta.getLuna().add(lunita);
		p.enviar();	
	}
}
