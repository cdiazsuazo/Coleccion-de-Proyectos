package ejerciciomultiplosdetres;

public class MultiplosDeTres {

	public static void main(String[] args) {
		
		//creamos un arreglo
		int SumaMultiplos = 0;//se crea variable
		
		
		int[] multiplos = new int[args.length];//se crea arreglo multiplos que se encuentra por elmomento vacio
		
		for (int i=0; i<multiplos.length; i++) {// con esto lleno el arreglo multiplos
												//al colocar length hace un recorrido y devuelve el largo
			multiplos[i] = Integer.parseInt(args[i]);//con esto parseo o transformo de String a Entero
		}
		SumaMultiplos = suma(multiplos); //se asigna un resultado a variable "sumaMultiplos" 
										//que es el metodo creado "suma" tomando los valores del parseo "multiplos"
										//que recive los valores de consola por medio del metodo "main" y se imprime 	
		System.out.println("Suma de Multiplos de 3 es:  " + SumaMultiplos);
		
		System.out.println ("Promedio es: " + promedio(multiplos));// llamo directamente al metodo "promedio" reciviendo valores 
												//de del parseo "multiplos" el cual recive los valores 	
	}											// de consola por el metodo "main" y la imprimo	
		// se crea un metodo llamado suma
	public static int suma(int[] Numero) {//aca se creas un metodo suma
		int totalSuma = 0;
		for( int i = 0; i<Numero.length; i++) {//se hace una iteracion para recorre el metodo
			if (Numero[i]%3==0) {
			totalSuma = Numero[i]+totalSuma;
			
			}
		}
		return totalSuma;
	}
	
	public static float promedio (int[]Numero) {// aca se crea el metodo promedio
		
		int suma = 0;
		float total = 0;
		int contador=0;
		
		for(int i = 0; i<Numero.length; i++) {// creamos iterancia del metodo
			if(Numero[i]%3==0) {// con esto sacamos los valores con multiplos de 3
				suma = Numero[i] + suma;
						contador++; //este contador es para incrementar la cantidad para poder dividir con este valor
			}
		}
		
		total = suma / contador; // aca se genera ya la parte final de la division la suma de los valores ingresados
								// divididos por el contador de la cantidad de valores
		
		return total;  
				
		
	}
		
	}
	

