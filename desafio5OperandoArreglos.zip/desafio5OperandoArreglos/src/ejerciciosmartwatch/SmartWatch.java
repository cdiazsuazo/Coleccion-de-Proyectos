package ejerciciosmartwatch;

import java.util.ArrayList;

public class SmartWatch {

	public static void main(String[] args) {// arreglo estatico guarda loingresado por consola
	
		// paso del arreglo estatico args al arreglo dinamico misPasos 
		
	ArrayList<Integer> misPasos = new ArrayList<Integer>(); // declarar un arreglo dinamico de tipo ArrayList Integer
	
	 for(int i=0; i<args.length; i++) { // for para recorrer el arreglo 
		 
		 misPasos.add( Integer.parseInt(args[i] ));// parse para convertir de String a un objeto de tipo entero
		 											//y agrego ese dato	
	 }
	 
	 //System.out.println(clearSteps(misPasos));
	//System.out.println(calcularPromedioPasos(clearSteps));
	 
	 
	 
	 ArrayList<Integer> pasoslimpios = clearSteps(misPasos);
	 
	 //System.out.println(pasoslimpios);
	 
	 float promedioFinal = promedioPasos(pasoslimpios);
	 
	 System.out.println("El Promedio de pasos es:  "+ promedioFinal);
	


	}
	
	public static ArrayList<Integer> clearSteps (ArrayList<Integer> numeroDePasos){
		
		ArrayList<Integer> misPasosConFiltro = new ArrayList<Integer>();//arreglo dinamico
		
		for(int i:numeroDePasos) {// for para recorrer el arreglo completo remplasa el recorrido
									//con Itereitor y solo para arreglos dinamicos
			
			if ( i>200 && i<100000) {//para sacar los menores de 200 y mayores de 100000
				
				misPasosConFiltro.add(i);
				
				
			}
			
		}
		//retorna el ArrayList misPasosConFiltro solo los valores que cumplan la condicion 
		return misPasosConFiltro;
	}
	
	public static float promedioPasos(ArrayList<Integer> pasosLimpios) {
		
		float suma = 0;
		
		for (int i:pasosLimpios) {
			
			suma = suma + i;
		
		}
		
		float promedio = suma / pasosLimpios.size();
		
		return promedio;
		
	}
	

	
	
	
	
	
}