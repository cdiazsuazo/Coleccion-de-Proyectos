package ejerciciovisitas;


public class Visitas {

	public static void main(String[] args) {

		if (args.length<=0) {
			System.out.println("Ingrese un valor por Favor");
			return;
		}
		Long[] visitas = new Long[args.length];

		for(int i=0; i<args.length; i++) {//recorre el arreglo


			visitas[i] = Long.parseLong(args[i]);

		}
		
		System.out.println("Para la entrada anterior, el resultado es:  " + promedio(visitas));
	}


	public static float promedio(Long [] visitas) {//metodo promedio reciviendo un arreglo long visitas
		float  PromedioTotal = 0;
		long  Total = 0;

		for( int contador = 0; contador<visitas.length; contador++) {//recorre el arreglo
			Total=Total + visitas[contador]; // Total de la suma de los numeros ingresados por el usuario
		}

		PromedioTotal = Total / visitas.length;

		return PromedioTotal;
	}




}	



	


