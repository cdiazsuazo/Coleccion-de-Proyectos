package com.desafiolatam.facade;

import java.sql.SQLException;
import java.util.List;

import com.desafiolatam.daos.CategoriaDAO;
import com.desafiolatam.daos.ProductoDAO;
import com.desafiolatam.dtos.CategoriaDTO;
import com.desafiolatam.dtos.ProductoDTO;



public class Facade {
	
	public int insertarProducto(ProductoDTO dto) throws SQLException, ClassNotFoundException {
		ProductoDAO insertarDao = new ProductoDAO();
		return insertarDao.insertarProducto(dto);
	}
	
	public List<CategoriaDTO> obtieneCategoria() throws SQLException, ClassNotFoundException{
		CategoriaDAO daoCategoria = new CategoriaDAO();
		return daoCategoria.obtieneCategoria();
	}
	
	public List<ProductoDTO> obtieneProductos() throws SQLException, ClassNotFoundException{
		ProductoDAO obtenerDao = new ProductoDAO();
		return obtenerDao.obtieneProductos();
	}
	
	public int borraProductos(Integer idUsuario) throws SQLException, ClassNotFoundException {
		ProductoDAO borrarDao = new ProductoDAO();
		return borrarDao.eliminaProductos(idUsuario);
	}

	public ProductoDTO encontrarProductos(Integer idUsuario) throws SQLException, ClassNotFoundException {
		ProductoDAO encontrarDao = new ProductoDAO();
		return encontrarDao.encuentraProductos(idUsuario);
	}
	
	public void editarProductos(ProductoDTO dto, Integer idProducto) throws SQLException, ClassNotFoundException {
		ProductoDAO editarDao = new ProductoDAO();
		editarDao.edicionProducto(dto, idProducto);
	}
	
}


