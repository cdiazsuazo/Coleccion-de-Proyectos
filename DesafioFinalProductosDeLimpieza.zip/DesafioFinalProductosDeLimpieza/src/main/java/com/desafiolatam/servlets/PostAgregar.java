package com.desafiolatam.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.desafiolatam.dtos.ProductoDTO;
import com.desafiolatam.facade.Facade;

/**
 * Servlet implementation class PostAgregar
 */
@WebServlet("/PostAgregar")
public class PostAgregar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PostAgregar() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//aqui capturamos lo que se agrega en el formulario
		String nombre = request.getParameter("nombre");
		Integer precio = Integer.parseInt(request.getParameter("precio"));
		String descripcion = request.getParameter("descripcion");
		Integer idCategoria = Integer.parseInt(request.getParameter("idCategoria"));
		
		//insertamos lo que se captura del formulario en un DTO en este caso ProductoDTO
		ProductoDTO dto = new ProductoDTO();
		dto.setNombre_producto(nombre);
		dto.setPrecio_producto(precio);
		dto.setDescripcion_producto(descripcion);
		dto.setId_categoria(idCategoria);
		
		//invocamos o llamamos al facade
		Facade facade = new Facade();
		int idProducto = 0; 
		
		try {
			// aqui ya finalmente se agrega al facade lo capturado por el formulario para entregarselo al dto
			idProducto = facade.insertarProducto(dto);
			
		} catch (SQLException | ClassNotFoundException e) {
			
		}
		
		request.setAttribute("idProducto", idProducto);// setea en el dto los parametros
		
		request.getRequestDispatcher("PreAgregar").forward(request, response);
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
