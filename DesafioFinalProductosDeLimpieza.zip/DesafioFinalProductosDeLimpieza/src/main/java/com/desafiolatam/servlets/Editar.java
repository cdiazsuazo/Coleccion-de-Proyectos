package com.desafiolatam.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.desafiolatam.dtos.CategoriaDTO;
import com.desafiolatam.dtos.ProductoDTO;
import com.desafiolatam.facade.Facade;

/**
 * Servlet implementation class Editar
 */
@WebServlet("/Editar")
public class Editar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Editar() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// instanciamos o llamamos al Facade
		Facade facade = new Facade();
		
		// con este capturamos el valor que se envia desde la tecla editar
		String idUsuario = request.getParameter("idUsuario");
		
		
		List<CategoriaDTO> listaCategorias = new ArrayList<CategoriaDTO>();
		
		//se crea un nuevo DTO llamado atributosProductos con sus atributos vacios para poder ser llenados
		ProductoDTO atributosProducto = new ProductoDTO();
		
		//Atributos Vacios
		String nombre = "";
		Integer precio = 0;
		String descripcion = "";
		Integer idCategoria = 0;
		
		try {
			// aca llenamos los atributos vacios con los parametros que recibimos
			
			listaCategorias = facade.obtieneCategoria();
			atributosProducto = facade.encontrarProductos(Integer.parseInt(idUsuario));
			nombre = atributosProducto.getNombre_producto();
			precio = atributosProducto.getPrecio_producto();
			descripcion = atributosProducto.getDescripcion_producto();
			idCategoria = atributosProducto.getId_categoria();
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		request.setAttribute("categoria", listaCategorias);
		request.setAttribute("idProducto", Integer.parseInt(idUsuario));
		request.setAttribute("nombre", nombre);
		request.setAttribute("precio",precio);
		request.setAttribute("descripcion", descripcion);
		request.setAttribute("idCategoria", idCategoria);
		
		request.getRequestDispatcher("edicion.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
