package com.desafiolatam.daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.desafiolatam.dtos.CategoriaDTO;





public class CategoriaDAO {
	
	public List<CategoriaDTO> obtieneCategoria() throws SQLException, ClassNotFoundException {
		
		//creamos la lista de objetos que devolveran los resultados
				List<CategoriaDTO> listaDeCategoria = new ArrayList<CategoriaDTO>();
				
				try {
					
				//creamos la consulta a la base de datos
				String consultaSql = "select id_categoria, nombre_categoria from categoria";
				
				//conexion a la base de datos y ejecucion de la sentencia
				Class.forName("org.postgresql.Driver");
				Connection conexion = null;
				
				conexion = DriverManager.getConnection("jdbc:postgresql://127.0.0.1:5432/Desafio_Final_productos_limpieza","postgres","admin");
				
				PreparedStatement stmt = conexion.prepareStatement(consultaSql);
				ResultSet resultado = stmt.executeQuery();
				
				
				while(resultado.next()) {
					CategoriaDTO categoriaDTO = new CategoriaDTO();
					categoriaDTO.setId_categoria(resultado.getInt("id_categoria"));
					categoriaDTO.setNombre_categoria(resultado.getString("nombre_categoria"));
					listaDeCategoria.add(categoriaDTO);
				}	
				
			}catch(Exception ex) {
				ex.printStackTrace();
				
			}
				return listaDeCategoria;
	}

}
