package com.desafiolatam.dtos;

public class ProductoDTO {
	
	private Integer id_producto;
	private String nombre_producto;
	private Integer precio_producto;
	private String descripcion_producto;
	private Integer id_categoria;
	/**
	 * @return the id_producto
	 */
	public Integer getId_producto() {
		return id_producto;
	}
	/**
	 * @param id_producto the id_producto to set
	 */
	public void setId_producto(Integer id_producto) {
		this.id_producto = id_producto;
	}
	/**
	 * @return the nombre_producto
	 */
	public String getNombre_producto() {
		return nombre_producto;
	}
	/**
	 * @param nombre_producto the nombre_producto to set
	 */
	public void setNombre_producto(String nombre_producto) {
		this.nombre_producto = nombre_producto;
	}
	/**
	 * @return the precio_producto
	 */
	public Integer getPrecio_producto() {
		return precio_producto;
	}
	/**
	 * @param precio_producto the precio_producto to set
	 */
	public void setPrecio_producto(Integer precio_producto) {
		this.precio_producto = precio_producto;
	}
	/**
	 * @return the descripcion_producto
	 */
	public String getDescripcion_producto() {
		return descripcion_producto;
	}
	/**
	 * @param descripcion_producto the descripcion_producto to set
	 */
	public void setDescripcion_producto(String descripcion_producto) {
		this.descripcion_producto = descripcion_producto;
	}
	/**
	 * @return the id_categoria
	 */
	public Integer getId_categoria() {
		return id_categoria;
	}
	/**
	 * @param id_categoria the id_categoria to set
	 */
	public void setId_categoria(Integer id_categoria) {
		this.id_categoria = id_categoria;
	}
	@Override
	public String toString() {
		return "ProductoDTO [id_producto=" + id_producto + ", nombre_producto=" + nombre_producto + ", precio_producto="
				+ precio_producto + ", descripcion_producto=" + descripcion_producto + ", id_categoria=" + id_categoria
				+ "]";
	}
	
	
	
	
	
}
